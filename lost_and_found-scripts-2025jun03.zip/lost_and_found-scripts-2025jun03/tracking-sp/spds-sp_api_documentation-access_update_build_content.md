# Amazon Selling Partner API Documentation  

**SUBTITLE**: ***Access, Update, and Build Content***   

The Amazon Selling Partner API \(Amazon SP API\), formerly known as Marketplace API and SPDS API, is the next generation control plane that works with Amazon Marketplace Web Service (Amazon MWS).  

The Amazon SP API documentation leverages the structures from the Amazon MWS documentation.  
The build directory and the source documentation directories are version controlled using git to synchronize with Amazon GitFarm repositories.  
The build workflow could be automated using a Pipeline, but is currently a manual process for all outputs. 


The following content describes the settings of the initial tools and ongoing requirements.  

**Contents**  
*   [Intended Audience](#intended-audience)  
*   [Requirements](#requirements)  
*   [Prerequisites](#prerequisites)  
    *   [Permissions](#permissions)  
    *   [Software](#software)  
*   [Reusable Variables](#reusable-variables)  
*   [Clone Repositories](#clone-repositories)  
    *   [Copy URI](#copy-uri)  
    *   [Use Git to Clone Repositories](#use-git-to-clone-repositories)   
*   [Replicate Content](#replicate-content)
    *   [Copy English Repository to Other Languages](#copy-english-repository-to-other-languages)  
    *   [Translate Other Language Repositories](#translate-other-language-repositories)  
*   [Save Changes to Repository](#save-changes-to-repository)  
*   [Generate Output](#generate-output)  
    *   [Generate GitHub-Flavored Markdown](#generate-github-flavored-markdown)  
    *   [Generate MWS-Styled xhtml](#generate-mws-styled-xhtml)  
    *   [Generate MWS-Styled pdf](#generate-mws-styled-pdf)  
*   [AWS Credentials](#aws-credentials)  
    *   [Get the AWS Credentials](#get-the-aws-credentials)  
    *   [Set the AWS Credentials](#set-the-aws-credentials)  
*   [Deploy](#deploy)  
    *   [Deploy xhtml to S3 Bucket](#deploy-xhtml-to-s3-bucket)  
    *   [Implement CloudSearch](#implement-cloudsearch)  
    *   [Invalidate CloudFront Distribution](#invalidate-cloudfront-distribution)  
*   [Appendix](#appendix)  
    *   [Appendix: Posix Commands](#appendix-posix-commands)  
        *   [Reusable Variables \(Posix\)](#reusable-variables-\(posix\))  
        *   [Use Git to Clone Repositories \(Posix\)](#use-git-to-clone-repositories-\(posix\))  
        *   [Generate GitHub-Flavored Markdown \(Posix\)](#generate-github-flavored-markdown-\(posix\))  
        *   [Set the AWS Credentials \(Posix\)](#set-the-aws-credentials-\(posix\))  
        *   [Push to S3 in Production \(Posix\)](#push-to-s3-in-production-\(posix\))  
    *   [Appendix: Git Desktop](#appendix-git-desktop)  
        *   [Use Git to Clone Repositories \(GitHub Desktop\)](#use-git-to-clone-repositories-\(github-desktop\))  



---  


## Intended Audience  

*   Spectrum Technical Writers (TWs) 
*   Stakeholders interested in the TW Process


### Permissions  

You must have access to [github.com/amzn/amazon-marketplace-api-sdk](https://github.com/amzn/amazon-marketplace-api-sdk).  
You must have access to [code.amazon.com](https://code.amazon.com).  
You must have access to the `SpectrumCM` team bindle.  
You must have access to the `MWS-AWS` AWS account.  


## Objective  

*  Successfully generate xhtml, pdf, and markdown outputs for the developer facing content.   


## Prerequisites  

In order to access, set up, and modify the Amazon SP API documentation in the required outputs.  


### Software  

You must install at least one package for each tool listed below.  

| Tool | Package | Download |  |   
|:--- |:--- |:--- | --- |  
| AWS | AWS CLI 64-bit | [aws.amazon.com/cli](https://aws.amazon.com/cli) | Required |  
| Git | git-scm 64-bit | [git-scm.com/downloads](https://git-scm.com/downloads) | Required |  
| Git | GitHub Desktop 64-bit | [desktop.github.com](https://desktop.github.com) | Optional |  
| JDK | Amazon Corretto JDK 64-bit | [aws.amazon.com/corretto](https://aws.amazon.com/corretto) | Required |  
| JDK | OpenJDK 64-bit | [openjdk.java.net/install](https://openjdk.java.net/install) | Optional |  
| JDK | Oracle Java JDK 64-bit | [www.oracle.com/technetwork/es/java/javasebusiness/downloads](https://www.oracle.com/technetwork/es/java/javasebusiness/downloads) | Optional |    


## Reusable Variables  

The following environment variables enable you to reuse the same section of text, or code.  
Using variables:  
*   Reduces the number of keystrokes.  
*   Increases consistency.  
*   Increases accuracy.  
*   Enables you to run commands from multiple tools  

The following variables reduce the amount of typing and ensure consistency in your day-to-day use.  
   
On Windows  
1.  Use the following command on the **Command Prompt** to set the variables found in the **Variable-Value** table.  
    
    ```cmd
    setx [variable_name] [value]
    ```  

| Variable | Value |  
|:--- |:--- |  
| BUILD_TOOLS_HOME | `C:\mws\git\build_tools` |  
| BUILD_HTML_HOME | `%BUILD_TOOLS_HOME%\build_html` |  
| DITA_DIR | `%BUILD_TOOLS_HOME%\DITA-OT1.8.5` |  
| GIT_SSH | `C:\Putty` |  
| JAVA_HOME | [location of your jdk] |  
| SP_HOME | `C:\spds` |  
| SP_BUILD_TOOLS_HOME | `%SP_HOME%\git\SPDSDocumentationBuild` |  
| SP_DITA_DIR |` %SP_BUILD_TOOLS_HOME%\dita-ot-3.3` |  
| SPUS | `%SP_HOME%\git\SPDSDocumentation-en_US` |  
| SPJP | `%SP_HOME%\git\SPDSDocumentation-ja_JP` |  
| SPBR | `%SP_HOME%\git\SPDSDocumentation-pt_BR` |  
| SPTR | `%SP_HOME%\git\SPDSDocumentation-tr_TR` |  
| SPCN | `%SP_HOME%\git\SPDSDocumentation-zh_CN` |  
| PATH | `%SP_DITA_DIR%\bin;%PATH%​` |  
| ANT_OPTS | `-Xmx512m %ANT_OPTS%` |  
| ANT_OPTS | `%ANT_OPTS% -Djavax.xml.transform.TransformerFactory=net.sf.saxon.TransformerFactoryImpl` |  
| ANT_HOME | `%DITA_DIR%\tools\ant` |  
| PATH | `%ANT_HOME%\bin;%JAVA_HOME%;%PATH%` |  
| CLASSPATH | `%DITA_DIR%\lib;%DITA_DIR%\lib\dost.jar;%DITA_DIR%\lib\commons-codec-1.4.jar;%DITA_DIR%\lib\resolver.jar;%DITA_DIR%\lib\icu4j.jar;` |  
| CLASSPATH | `%DITA_DIR%\lib\xercesImpl.jar;%DITA_DIR%\lib\xml-apis.jar;%CLASSPATH%` |  
| CLASSPATH | `%DITA_DIR%\lib\saxon\saxon9.jar;%DITA_DIR%\lib\saxon\saxon9-dom.jar;%CLASSPATH%` |  
| AWS_ACCESS_KEY_ID | [AWS access key] |  
| AWS_SECRET_ACCESS_KEY | [AWS secret key] |  
| AWS_DEFAULT_REGION | `us-east-1` |  


## Clone Repositories  

On your local machine or Cloud/Dev Desktop, you must repeat the following steps to access the GitFarm repositories and create local copies.  This step in required is you plane to review, edit, or build the Amazon SP API documentation.  
Due to style compatibility, the html output is built using a modified branch of the MWS Build repository.  The markdown output is built using the SP API build repository.  


### Copy URI  

The secure address for each repository is used to access and clone. You must know the secure address before you create a local copy.  

In your **Web browser**, perform the following tasks.  
1.  Visit **Code Browser** page for each repository 
    1.  Copy the uri for the **Clone uri** text box  
    2.  Save the uri for later use  

After completing this task for each package, you have the following uri values for each of the empty repositories on GitFarm.  

|  | GitFarm Location | Clone uri |  
|:--- |:--- |:--- |  
| MWS Build | [code.amazon.com/packages/MWSDocumentationBuild](https://code.amazon.com/packages/MWSDocumentationBuild) | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` |  
| SP API Build | [code.amazon.com/packages/SPDSDocumentationBuild](https://code.amazon.com/packages/SPDSDocumentationBuild) | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` |  
| English | [code.amazon.com/packages/SPDSDocumentation-en_US]([https://code.amazon.com/packages/SPDSDocumentation-en_US) | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` |  
| Japanese | [code.amazon.com/packages/SPDSDocumentation-ja_JP](https://code.amazon.com/packages/SPDSDocumentation-ja_JP) | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` |  
| Portuguese | [code.amazon.com/packages/SPDSDocumentation-pt_BR](https://code.amazon.com/packages/SPDSDocumentation-pt_BR) | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` |  
| Turkish | [code.amazon.com/packages/SPDSDocumentation-tr_TR](https://code.amazon.com/packages/SPDSDocumentation-tr_TR) | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` |  
| Chinese | [code.amazon.com/packages/SPDSDocumentation-zh_CN](https://code.amazon.com/packages/SPDSDocumentation-zh_CN) | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` |  


### Use Git to Clone Repositories  

You use the secure address to create a local copy using the `git clone` command via the command-line.  
You may use the **GitHub Desktop** application in place of the command-line.  

*   If you use a command-line tool or shell, use the following steps to create a local clone for each repository.  
    1.  Create a directory for each repository using the **Command Prompt** in Windows  
            
            ```cmd
            ​md [local_path]
            ```  
            
    2.  Use the `git clone` command to attach each GitFarm repository to each local directory.  
        
        ```shell
        git clone [clone_uri] [local_path]
        ```  

    3.  Navigate to each directory.  
        
        ```shell
        cd [local_path]
        ```  
        
    4.  Checkout the `mainline` branch for each repository.  
        
        ```shell
        git checkout mainline​
        ```  

After completing this task for each of the repositories, you have local directories cloned for each of the GitFarm repositories.  

*   On Windows  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |  
    | MWS Build | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` | C:\mws\git\build_tools |  
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | C:\spds\git\SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | C:\spds\git\SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | C:\spds\git\SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | C:\spds\git\SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | C:\spds\git\SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | C:\spds\git\SPDSDocumentation-zh_CN |  


## Replicate Content  

Each language may have ongoing replication due to changes and the selected translation process.  


### Copy English Repository to Other Languages  

After you Copy the DITA xml topic files, DITA Map, and directory structure from the English repository into each of the other language repositories.  
*   Japanese : `ja_JP`  
*   Portugeuse : `pt_BR`  
*   Turkish : `tr_TR`  
*   Chinese : `zh_CN`  

\[Under Construction\]


### Translate Other Language Repositories  

**REVIEW NOTE**: Work with Simona to determine effort and timeline requirements.  

\[Under Construction\]


## Save Changes to Repository  

1.  Save the changes to the files and directories.  

2.  Add files to track in a commit.  
    In the directory associated with the repository, add a file.  

    ```shell
    git add [path/to/file_name.ext]
    ```  

2.  Create a commit.  
    In the directory associated with the repository, create a commit associated with the tracked files.  

    ```shell
    git -am commit "[insert_commit_message]"
    ```  

3.  Push all commits to the repository.   
    In the directory associated with the repository, push the commits.  

    ```shell
    git push
    ```  

After completing this task, you have pushed your local changes to the associated GitFarm repository.  


## Generate Output  


### Generate GitHub-Flavored Markdown  

The following script uses the `dita` command to generate GitHub-flavored markdown for all of the current languages.  

1.  Copy the following text
    
    ```cmd
    setx OUTPUT_HOME="%SP_HOME%\_out"
    setx GHMD_HOME="%OUTPUT_HOME%\gh-md"

    if EXIST "%GHMD_HOME%\" ( del /F /S /Q "%GHMD_HOME%\*" )

    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_AU.ditaval --format=markdown_github --output=%GHMD_HOME%\en_AU\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_CA.ditaval --format=markdown_github --output=%GHMD_HOME%\en_CA\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_DE.ditaval --format=markdown_github --output=%GHMD_HOME%\en_DE\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_ES.ditaval --format=markdown_github --output=%GHMD_HOME%\en_ES\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_FR.ditaval --format=markdown_github --output=%GHMD_HOME%\en_FR\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_IN.ditaval --format=markdown_github --output=%GHMD_HOME%\en_IN\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_IT.ditaval --format=markdown_github --output=%GHMD_HOME%\en_IT\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_MX.ditaval --format=markdown_github --output=%GHMD_HOME%\en_MX\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_UK.ditaval --format=markdown_github --output=%GHMD_HOME%\en_UK\
    dita --input=%SPUS%\HTML_EN.ditamap --filter=%SPUS%\HTML_US.ditaval --format=markdown_github --output=%GHMD_HOME%\en_US\
    dita --input=%SPJP%\HTML_JP.ditamap --filter=%SPJP%\HTML_JP.ditaval --format=markdown_github --output=%GHMD_HOME%\ja_JP\
    dita --input=%SPBR%\HTML_BR.ditamap --filter=%SPBR%\HTML_BR.ditaval --format=markdown_github --output=%GHMD_HOME%\pt_BR\
    dita --input=%SPTR%\HTML_TR.ditamap --filter=%SPTR%\HTML_TR.ditaval --format=markdown_github --output=%GHMD_HOME%\tr_TR\
    dita --input=%SPCN%\HTML_CN.ditamap --filter=%SPCN%\HTML_CN.ditaval --format=markdown_github --output=%GHMD_HOME%\zh_CN\
    ```  

2.  Save as a script file named `spapi-build_ghmd.bat`  
3.  Run the script on the **Command Prompt**  

After completing this task, you have markdown files for each language and locale in the `gh-md` directory in the `_out` directory.  


### Generate MWS-Styled xhtml  

The following steps help you generate MWS-style xhml files for the SP API DITA files.  

1.  On the command-line or **GitHub Desktop**
    1.  Open the `build_tools` directory.  
    2.  Change the branch to `spds-no_cloudsearch`.  
2.  In the file browser  
    1.  Open the `build_html` directory in the `build_tools` directory.  
    1.  Select the `startcmd.bat` file and run as administrator.  
3.  On the **MWS Command Prompt**  
    1.  Run the following commands to build the SP API html files.
        *   `build local all`  : For building content from the currently checked-out branch.  
        *   `build master all`  : For building content from the `mainline` branch.  

After completing this task, you have html files for each language and locale in the `spapi` directory in the branch \(`local` or `mainline`\) directory in the `_out` directory.  


### Generate MWS-Styled pdf  

1.  In **OxygenXML**  
    1.  Open the ditamap file.  
    2.  Click on the `Apply Transformation Scenario(s)` icon.  
    3.  Select the `DITA Map PDF (MWS) - US` checkbox.  
    4.  Click on `Apply associated (#)` button.  
    5.  Review pdf file.  


## AWS Credentials  


### Get the AWS Credentials  

To deploy html content to an S3 bucket, you must be able to authenticate your AWS requests.  

You must acquire the following AWS keys.  
*   AWS Access Key ID  
*   AWS Secret Access Key  

> **NOTE**: If you make a request to AWS and receive an error message, please follow these steps to get new instances of the AWS keys.  

1.  Access a Cloud/Dev Desktop that has `odin-get` installed.  
    *   If you are running Windows and do not have a Cloud/Dev Desktop.  
        1.  In the **web browser**
            1.  Visit the [apollo.amazon.com/environments/MarketplaceWebServiceAuthorizationTools/NA/stages/Beta](https://apollo.amazon.com/environments/MarketplaceWebServiceAuthorizationTools/NA/stages/Beta) page.  
            2.  Under the **Beta** tab, in the **Auto Scaling Groups** section, under the **Tag** heading, expand the **2A** selection.  
                *   Copy the new host name and save it for the next step.  
        2.  In **PuTTY**  
            1.  In **Connection** > **SSH**  
                *   Under **SSH protocol version**, select the `2` radio button  
            2.  In **session**  
                *   In the **Host Name \(or IP address\)** text box, enter `beta-tools-na-2a-9d4be40a.us-west-2.amazon.com`  
                *   In the **Port** text box, enter `22`  
            3.  Click on **Open** button.  
2.  Run the following command.  
    
    ```bash
    /apollo/env/envImprovement/bin/odin-get com.amazon.access.MWS-AWS-mws-tech-writers-1
    ```  

3.  Copy the AWS credentials and save both for the [Set the AWS Credentials](#set-the-aws-credentials) section.  


### Set the AWS Credentials  

Save your credentials as environement variables.  
            
1.  On the **Command Prompt** in Windows  
            
    ```cmd
    setx AWS_ACCESS_KEY_ID [aws_access_key_id_value]
    setx AWS_SECRET_ACCESS_KEY [aws_secret_access_key_value]
    setx AWS_DEFAULT_REGION us-east-1
    ```  

After completing this task, you have AWS credentials stored and avaialble of your machine.  


## Deploy  


### Deploy xhtml to S3 Bucket  

The upload for xhtml content is replicated from the MWS scripts.  
Prior to uploading the files for MWS is placed into the directory named `mws` and the files for SP API is placed into the directory name `spapi`.  

Content is deployed to `devo/beta` or `prod`.  


#### Push to S3 in Production  

Upload all of the html content to the S3 bucket.  
            
1.  On the **Command Prompt** in Windows  
            
    ```cmd
    set HTML_UPLOAD="%SP_HOME%\_out\mainline"

    aws s3 sync "%HTML_UPLOAD%" "[s3_bucket]" --delete --exclude "%HTML_UPLOAD%\docs.html" --include "%HTML_UPLOAD%\css\*" --region %AWS_DEFAULT_REGION% --source-region %AWS_DEFAULT_REGION%
    ```  
    
After completing this task, you have uploaded the html files into an S3 bucket.  

|  | S3 bucket |  
|:--- |:--- |  
| beta/devo | s3://devo.docs.developer.amazonservices.com |  
| prod | s3://docs.developer.amazonservices.com |  


### Implement CloudSearch  

The implementation of CloudSearch is replicated from the MWS implementation that Kason is building.  

\[Under Construction\]


### Invalidate CloudFront Distribution  

The script and steps for invalidating the Cloudfront distribution is replicated from the MWS implementation and performs the same task.  


*   If you use a command-line tool
    
    ```shell
    aws cloudfront create-invalidation --distribution-id E1LZRMHNBQ2JCH --paths /*
    ```  

*   In your **Web browser**, perform the following tasks.  
    1.  Visit the [MWS-AWS AWS Account](https://access.amazon.com/aws/accounts/show/MWS-AWS) page.  
        1.  Click on the **Console Access** button.  
    2.  On the **AWS Management Console** page, under **Networking \& Content Delivery** section or the **Recently visited services** section.  
        1.  Click on the  **CloudFront** link.  
    3.  On the **CloudFront Distributions** page.  
        1.  Click on the `E1LZRMHNBQ2JCH`.  
    4.  On the **CloudFront Distributions** > `E1LZRMHNBQ2JCH` page.  
        1.  Select the **Invalidation** tab.  
            1.  Click on the **Create Invalidation** button.  
    5.  On the **Create Invalidation** pop-up window.  
        1.  In the **Object Paths** textbox, enter the following.  

            ```
            /*
            ```  

        2.  Click on the **Invalidate** button.  

After completing this task, you have initiated the content refresh.  


### Verify Live Content  

*   In your **Web browser**, perform the following tasks.  
    1.  Visit the following pages.  
        *   [docs.developer.amazonservices.com/mws/en_US/dev_guide](http://docs.developer.amazonservices.com/mws/en_US/dev_guide)  
        *   [docs.developer.amazonservices.com/mws/ja_JP/dev_guide](http://docs.developer.amazonservices.com/mws/ja_JP/dev_guide)  
        *   [docs.developer.amazonservices.com/mws/zh_CN/dev_guide](http://docs.developer.amazonservices.com/mws/zh_CN/dev_guide)  
        *   [docs.developer.amazonservices.com/spapi/en_US/developer_guide](http://docs.developer.amazonservices.com/spapi/en_US/developer_guide)  
        *   [docs.developer.amazonservices.com/spapi/ja_JP/developer_guide](http://docs.developer.amazonservices.com/spapi/ja_JP/developer_guide)  
        *   [docs.developer.amazonservices.com/spapi/pt_BR/developer_guide](http://docs.developer.amazonservices.com/spapi/pt_BR/developer_guide)  
        *   [docs.developer.amazonservices.com/spapi/tr_TR/developer_guide](http://docs.developer.amazonservices.com/spapi/tr_TR/developer_guide)  
        *   [docs.developer.amazonservices.com/spapi/zh_CN/developer_guide](http://docs.developer.amazonservices.com/spapi/zh_CN/developer_guide)  

After completing this task, you have the html files refreshed on the live site.  


## Appendix  


### Appendix: Posix Commands  

Alternate direction for using the `bash` shell.  


#### Reusable Variables \(Posix\)  

On Posix \(GNU/linux, macOS, UNIX\)  
1.  Use the following command to set the variables found in the table.  
    
    ```bash
    export [variable_name]=[value]
    ```  
    
    | Variable | Value |  
    |:--- |:--- |  
    | BUILD_TOOLS_HOME | `/mws/git/build_tools` |  
    | BUILD_HTML_HOME | `$BUILD_TOOLS_HOME/build_html` |  
    | DITA_DIR | `$BUILD_TOOLS_HOME/DITA-OT1.8.5` |  
    | GIT_SSH | [location of your ssh] |  
    | JAVA_HOME | [location of your jdk] |  
    | SP_HOME | `/spds` |  
    | SP_BUILD_TOOLS_HOME | `$SP_HOME/git/SPDSDocumentationBuild` |  
    | SP_DITA_DIR | `$SP_BUILD_TOOLS_HOME/dita-ot-3.3` |  
    | SPUS | `$SP_HOME/git/SPDSDocumentation-en_US` |  
    | SPJP | `$SP_HOME/git/SPDSDocumentation-ja_JP` |  
    | SPBR | `$SP_HOME/git/SPDSDocumentation-pt_BR` |  
    | SPTR | `$SP_HOME/git/SPDSDocumentation-tr_TR` |  
    | SPCN | `$SP_HOME/git/SPDSDocumentation-zh_CN` |  
    | PATH | `$SP_DITA_DIR\bin;$PATH​` |   
    | ANT_OPTS | `-Xmx512m $ANT_OPTS -Djavax.xml.transform.TransformerFactory=net.sf.saxon.TransformerFactoryImpl` |  
    | ANT_HOME | `$DITA_DIR/tools/ant` |  
    | PATH | `$ANT_HOME/bin;$JAVA_HOME;$PATH` |  
    | CLASSPATH | `$DITA_DIR/lib;$DITA_DIR/lib/dost.jar;$DITA_DIR/lib/commons-codec-1.4.jar;$DITA_DIR/lib/resolver.jar;$DITA_DIR/lib/icu4j.jar;` |  
    | CLASSPATH | `$DITA_DIR/lib/xercesImpl.jar;$DITA_DIR/lib/xml-apis.jar;$CLASSPATH` |  
    | CLASSPATH | `$DITA_DIR/lib/saxon/saxon9.jar;$DITA_DIR/lib/saxon/saxon9-dom.jar;$CLASSPATH` |  
    | AWS_ACCESS_KEY_ID | [AWS access key] |  
    | AWS_SECRET_ACCESS_KEY | [AWS secret key] |  
    | AWS_DEFAULT_REGION | `us-east-1` |  


#### Use Git to Clone Repositories \(Posix\)  

You use the secure address to create a local copy using the `git clone` command via the command-line.  
You may use the **GitHub Desktop** application in place of the command-line.  

*   If you use a command-line tool or shell, use the following steps to create a local clone for each repository.  
    1.  Create a directory for each repository.  
        *   If you use the `bash` shell  on Posix or Windows
                        
            ```bash
            mkdir [local_path]
            ```   
            
    2.  Use the `git clone` command to attach each GitFarm repository to each local directory.  
        
        ```shell
        git clone [clone_uri] [local_path]
        ```  

    3.  Navigate to each directory.  
        
        ```shell
        cd [local_path]
        ```  
        
    4.  Checkout the `mainline` branch for each repository.  
        
        ```shell
        git checkout mainline​
        ```  
After completing this task for each of the repositories, you have local directories cloned for each of the GitFarm repositories.  

*   On Posix  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |  
    | MWS Build | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` | /mws/git/build_tools |  
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | /spds/git/SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | /spds/git/SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | /spds/git/SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | /spds/git/SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | /spds/git/SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | /spds/git/SPDSDocumentation-zh_CN |  
    
*   On Windows using `bash`  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |  
    | MWS Build | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` | /c/mws/git/build_tools |  
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | /c/spds/git/SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | /c/spds/git/SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | /c/spds/git/SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | /c/spds/git/SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | /c/spds/git/SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | /c/spds/git/SPDSDocumentation-zh_CN |  


#### Generate GitHub-Flavored Markdown \(Posix\)  

The following script uses the `dita` command to generate GitHub-flavored markdown for all of the current languages.  

*   1.  Copy the following text
    
    ```bash
    export OUTPUT_HOME="$SP_HOME/_out"
    export GHMD_HOME="$OUTPUT_HOME/gh-md"

    rm -fr "$GHMD_HOME/*"

    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_AU.ditaval --format=markdown_github --output=$GHMD_HOME/en_AU/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_CA.ditaval --format=markdown_github --output=$GHMD_HOME/en_CA/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_DE.ditaval --format=markdown_github --output=$GHMD_HOME/en_DE/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_ES.ditaval --format=markdown_github --output=$GHMD_HOME/en_ES/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_FR.ditaval --format=markdown_github --output=$GHMD_HOME/en_FR/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_IN.ditaval --format=markdown_github --output=$GHMD_HOME/en_IN/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_IT.ditaval --format=markdown_github --output=$GHMD_HOME/en_IT/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_MX.ditaval --format=markdown_github --output=$GHMD_HOME/en_MX/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_UK.ditaval --format=markdown_github --output=$GHMD_HOME/en_UK/
    dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_US.ditaval --format=markdown_github --output=$GHMD_HOME/en_US/
    dita --input=$SPJP/HTML_JP.ditamap --filter=$SPJP/HTML_JP.ditaval --format=markdown_github --output=$GHMD_HOME/ja_JP/
    dita --input=$SPBR/HTML_BR.ditamap --filter=$SPBR/HTML_BR.ditaval --format=markdown_github --output=$GHMD_HOME/pt_BR/
    dita --input=$SPTR/HTML_TR.ditamap --filter=$SPTR/HTML_TR.ditaval --format=markdown_github --output=$GHMD_HOME/tr_TR/
    dita --input=$SPCN/HTML_CN.ditamap --filter=$SPCN/HTML_CN.ditaval --format=markdown_github --output=$GHMD_HOME/zh_CN/
    ```  

2.  Save as a script file named `spapi-build_ghmd.sh`  
3.  Run the script on the `bash` shell  

After completing this task, you have markdown files for each language and locale in the `gh-md` directory in the `_out` directory. 


#### Set the AWS Credentials \(Posix\)  

Save your credentials as environement variables.  


*   If you use the `bash` shell on Posix or Windows
                        
    ```bash
    export AWS_ACCESS_KEY_ID=[aws_access_key_id_value]
    export AWS_SECRET_ACCESS_KEY=[aws_secret_access_key_value]
    export AWS_DEFAULT_REGION=us-east-1
    ```  

After completing this task, you have AWS credentials stored and avaialble of your machine.  


#### Push to S3 in Production \(Posix\)  

Upload all of the html content to the S3 bucket.  

*   If you use the `bash` shell on Posix or Windows
                        
    ```bash
    export HTML_UPLOAD="$SP_HOME/_out/mainline"

    aws s3 sync "$HTML_UPLOAD" "[s3_bucket]" --delete --exclude "$HTML_UPLOAD/docs.html" --include "$HTML_UPLOAD/css/*" --region $AWS_DEFAULT_REGION --source-region $AWS_DEFAULT_REGION
    ```  
    
After completing this task, you have uploaded the html files into an S3 bucket.  

|  | S3 bucket |  
|:--- |:--- |  
| beta/devo | s3://devo.docs.developer.amazonservices.com |  
| prod | s3://docs.developer.amazonservices.com |  


### Appendix: Git Desktop  

Alternate direction for using GitHub Desktop.  

#### Use Git to Clone Repositories \(GitHub Desktop\)  

*   If you use **GitHub Desktop**, use the following steps to create a local clone for each repository.  
    1.  Open the **Clone a repository** pop-up window using one of the following options.  
        *   Select **File** > **Clone Repository...**  
        *   Press `Ctrl`+`Shift`+`O`  
        *   Click on **Current repository** button, click on **Add** button, and select **Clone Repository...**  
    2.  On the **Clone a repository** pop-up window.  
        1.  Select the **URL** tab.  
            *   In the **Repository URl or GitHub username and repository** text box, enter the **Clone uri** value.
            *   In the **Local path** text box, enter the local path.  
        2.  Click on **Clone** button.  

After completing this task for each of the repositories, you have local directories cloned for each of the GitFarm repositories.  

*   On Posix  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |  
    | MWS Build | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` | /mws/git/build_tools |  
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | /spds/git/SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | /spds/git/SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | /spds/git/SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | /spds/git/SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | /spds/git/SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | /spds/git/SPDSDocumentation-zh_CN |  
    
*   On Windows using `bash`  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |  
    | MWS Build | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` | /c/mws/git/build_tools |  
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | /c/spds/git/SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | /c/spds/git/SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | /c/spds/git/SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | /c/spds/git/SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | /c/spds/git/SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | /c/spds/git/SPDSDocumentation-zh_CN |  
    
*   On Windows  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |  
    | MWS Build | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` | C:\mws\git\build_tools |  
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | C:\spds\git\SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | C:\spds\git\SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | C:\spds\git\SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | C:\spds\git\SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | C:\spds\git\SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | C:\spds\git\SPDSDocumentation-zh_CN |  