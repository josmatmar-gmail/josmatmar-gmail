# !/bin/bash

# sysinfo_page - A script to produce html for Swagger JSON
## Archive previous build and create new build directory

SPDS_MODEL_DIR="/c/spds/git/AMDSAPISwaggerModels/swagger-models"
CODEGEN_DIR="/c/spds/downloads/swagger-codegen"
SPDS_REF_BUILD_DIR="/c/spds/_out/api_ref"

if [ ! -d $SPDS_REF_BUILD_DIR ]; then
   echo "Create $SPDS_REF_BUILD_DIR directory"
   mkdir $SPDS_REF_BUILD_DIR
fi
    
## Copy JSON into directories
echo "=== Copy JSON into directories ==="
for file in $SPDS_MODEL_DIR/*.json
do
    file_ext="$(basename "$file")"
    file_sh="${file_ext%.*}"
    if [ ! -d $SPDS_REF_BUILD_DIR/$file_sh ]; then
       echo "Create $SPDS_REF_BUILD_DIR/$file_sh directory"
       mkdir $SPDS_REF_BUILD_DIR/$file_sh
    fi
    echo "$file_ext --> $SPDS_REF_BUILD_DIR/$file_sh/$file_ext"
    cp -f "$file" "$SPDS_REF_BUILD_DIR/$file_sh/$file_ext"
done

## Run code gen for all json in directory
echo "== Generate html from JSON =="
for file in $SPDS_MODEL_DIR/*.json
do
    file_ext="$(basename "$file")"
    file_sh="${file_ext%.*}"
    java -jar $CODEGEN_DIR/swagger-codegen-cli.jar generate --lang html2 --input-spec "$file" --output "$SPDS_REF_BUILD_DIR"
    echo "$file_ext --> $SPDS_REF_BUILD_DIR/$file_sh/$file_sh.html"
    mv -f "$SPDS_REF_BUILD_DIR/index.html" "$SPDS_REF_BUILD_DIR/$file_sh/$file_sh.html"
done

echo "==============================="

## Delete the temporary files
rm -fr "$SPDS_REF_BUILD_DIR/.swagger-codegen"
rm -fr "$SPDS_REF_BUILD_DIR/.swagger-codegen-ignore"
rm -fr "$SPDS_REF_BUILD_DIR/index.html"
