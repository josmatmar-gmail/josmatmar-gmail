# Create directory for repos  

``` shell
cd /
mkdir "spectrum"
cd "spectrum"
mkdir "git"
cd git
```  

## Clone swagger-codegen repo  

``` git
git clone https://github.com/swagger-api/swagger-codegen.git
```  

## Clone AMDSAPISwaggerModels repo  

``` git
git clone ssh://git.amazon.com/pkg/AMDSAPISwaggerModels
```  

## Change directory to target directory for output  

``` shell
cd "/c/spectrum/git/AMDSAPISwaggerModels/swagger-models"
```  

## Run codegen  

``` shell
java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "abecedary.json"
mv "index.html" "/c/spectrum/outfile/abecedary.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "buyerSubscriptions.json"
mv "index.html" "/c/spectrum/outfile/buyerSubscriptions.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "catalog.json"
mv "index.html" "/c/spectrum/outfile/catalog.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "catalog_prototypes.json"
mv "index.html" "/c/spectrum/outfile/catalog_prototypes.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "Labyrinth.json"
mv "index.html" "/c/spectrum/outfile/Labyrinth.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "LabyrinthRPC.json"
mv "index.html" "/c/spectrum/outfile/LabyrinthRPC.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "listings.json"
mv "index.html" "/c/spectrum/outfile/listings.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "orders.json"
mv "index.html" "/c/spectrum/outfile/orders.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "sales.json"
mv "index.html" "/c/spectrum/outfile/sales.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "sellers.json"
mv "index.html" "/c/spectrum/outfile/sellers.html"

java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "smallAndLight.json"
mv "index.html" "/c/spectrum/outfile/smallAndLight.html"


rm -fr ".swagger-codegen"
rm -fr ".swagger-codegen-ignore"
```  

## Run code gen for all json in directory  

``` shell
for file in *.json
do
    java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "$file"
    mv "index.html" "/c/spds/outfile/$file.html"
done

rm -fr ".swagger-codegen"
rm -fr ".swagger-codegen-ignore"
```  