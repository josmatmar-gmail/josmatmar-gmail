ECHO off

ECHO Adding MWS variables...
if not defined BUILD_TOOLS_HOME ( setx BUILD_TOOLS_HOME C:\mws\git\build_tools )
if not defined BUILD_HTML_HOME ( setx BUILD_HTML_HOME C:\mws\git\build_tools\build_html )
if not defined DITA_DIR ( setx DITA_DIR C:\mws\git\build_tools\DITA-OT1.8.5 )

ECHO Adding Applications...
if not defined GIT_SSH ( setx /M GIT_SSH "C:\Program Files\PuTTY\plink.exe" )
if not defined JAVA_HOME ( setx /M JAVA_HOME "C:\Program Files\Amazon Corretto\jdk11.0.3_7" )

ECHO Adding SP API variables...
if not defined SP_HOME ( setx SP_HOME C:\spds )
if not defined SP_BUILD_TOOLS_HOME ( setx SP_BUILD_TOOLS_HOME C:\spds\git\SPDSDocumentationBuild )
if not defined SP_DITA_DIR ( setx SP_DITA_DIR C:\spds\git\SPDSDocumentationBuild\dita-ot-3.3 )
if not defined SPUS ( setx SPUS C:\spds\git\SPDSDocumentation-en_US )
if not defined SPJP ( setx SPJP C:\spds\git\SPDSDocumentation-ja_JP )
if not defined SPBR ( setx SPBR C:\spds\git\SPDSDocumentation-pt_BR )
if not defined SPTR ( setx SPTR C:\spds\git\SPDSDocumentation-tr_TR )
if not defined SPCN ( setx SPCN C:\spds\git\SPDSDocumentation-zh_CN )

ECHO Updating Path to include MWS DITA...
set /M PATH "%PATH%;C:\mws\git\build_tools\DITA-OT1.8.5\bin​"

ECHO Updating Path to include SP API DITA...
setx /M PATH "%PATH%;C:\spds\git\SPDSDocumentationBuild\dita-ot-3.3\bin​"

ECHO Adding build options to ANT...
if not defined ANT_OPTS ( setx /M ANT_OPTS="-Xmx512m %ANT_OPTS%"
setx /M ANT_OPTS "%ANT_OPTS% -Djavax.xml.transform.TransformerFactory=net.sf.saxon.TransformerFactoryImpl" )

ECHO Adding ANT variable...
if not defined ANT_HOME ( setx ANT_HOME C:\mws\git\build_tools\DITA-OT1.8.5\tools\ant )

ECHO Updating Path to include ANT...
setx /M PATH "%PATH%;C:\mws\git\build_tools\DITA-OT1.8.5\tools\ant\bin;C:\Program Files\Amazon Corretto\jdk11.0.3_7"

ECHO Updating ClassPath to include MWS DITA libraries...
setx /M CLASSPATH "C:\mws\git\build_tools\DITA-OT1.8.5\lib;C:\mws\git\build_tools\DITA-OT1.8.5\lib\dost.jar;C:\mws\git\build_tools\DITA-OT1.8.5\lib\commons-codec-1.4.jar;C:\mws\git\build_tools\DITA-OT1.8.5\lib\resolver.jar;C:\mws\git\build_tools\DITA-OT1.8.5\lib\icu4j.jar;"
setx /M CLASSPATH "C:\mws\git\build_tools\DITA-OT1.8.5\lib\xercesImpl.jar;C:\mws\git\build_tools\DITA-OT1.8.5\lib\xml-apis.jar;%CLASSPATH%"
setx /M CLASSPATH "C:\mws\git\build_tools\DITA-OT1.8.5\lib\saxon\saxon9.jar;C:\mws\git\build_tools\DITA-OT1.8.5\lib\saxon\saxon9-dom.jar;%CLASSPATH%"

ECHO Adding AWS variables...
if not defined AWS_ACCESS_KEY_ID ( setx AWS_ACCESS_KEY_ID AKIA3ITE6SW44IH7DXUY )
if not defined AWS_SECRET_ACCESS_KEY ( setx AWS_SECRET_ACCESS_KEY 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 )
if not defined AWS_DEFAULT_REGION ( setx AWS_DEFAULT_REGION us-east-1 )

