# Create SP API Reference Docs  

The Amazon Selling Partner API (Amazon SP API) reference documentation is delivered in Swagger JSON files and Swagger generated html.  All SP APIs have an SPDS JSON files that describes the model.  The SPDS JSON files reside in the same Octane package (Gitfarm repository) at [code.amazon.com/packages/AMDSAPISwaggerModels](https://code.amazon.com/packages/AMDSAPISwaggerModels/trees/APIG).  

The Swagger JSON files are generated using the Swagger Codegen tool.  The Swagger Codegen tool is also used to create the SP API html.  This is useful for ensureing that your content appears in the html prior to requesting SPDS review.  

The following directions walk you through the process of generating SP API html from a Swagger JSON file.  


@[toc]  


<!-- **Contents** 
*   [Install Apache Maven](#install-apache-maven)
*   [Download prebuilt swagger-codegen](#download-prebuilt-swagger-codegen)  
*   [Create local repo for SPDS API reference](#create-local-repo-for-spds-api-reference)  -->

<!-- 
## Install Apache Maven  

1.  Download Maven  
    *   [maven.apache.org/download.cgi](https://maven.apache.org/download.cgi)  

2.  Unzip archive
    
    **bash**
    ```bash
    unzip ~/Downloads/apache-maven-3.6.1-bin.zip -d /c/third-party/
    ```  

3.  Add Maven to PATH
    
    **cmd**
    ```cmd
    setx PATH "C:\third-party\apache-maven-3.6.1\bin;%PATH%"
    ```  

4.  Verify 

    **bash**
    ```bash
    mvn -v
    ```  

### Install Surefire plugin for Apache Maven  

1.  Download Surefire  
    *   [maven.apache.org/surefire/download.cgi](https://maven.apache.org/surefire/download.cgi)  

2.  2.  Unzip archive
    
    **bash**
    ```bash
    unzip ~/Downloads/surefire-3.0.0-M3-source-release.zip -d /c/third-party/
    ```  

3.  Add Surefire to PATH
    
    **cmd**
    ```cmd
    setx PATH "C:\third-party\surefire-3.0.0-M3\bin;%PATH%"
    ```  

4.  Verify 

    **bash**
    ```bash
    mvn -v
    ```  


## Install swagger codegen  


### Clone the repo into a local directory for swagger-codegen  

> **git bash**  
> 
> > ```  
> > git clone https://github.com/swagger-api/swagger-codegen.git /c/third-party/git/swagger-codegen
> >
> > cd /c/third-party/git/swagger-codegen
> > 
> > git checkout master
> > ```  
> **git via cmd**  
> 
> > ```  
> > git clone https://github.com/swagger-api/swagger-codegen.git C:\third-party\git\swagger-codegen
> >
> > cd C:\third-party\git\swagger-codegen
> > 
> > git checkout master
> > ```  
> **Git Desktop**  
> 
> > 1.  Clone a repository by choosing one of the following methods.  
> >     *   Select **File** > **Clone Repository...**  
> >     *   Press `Ctrl`+`Shift`+`O`  
> >     *   Click on **Current repository** button, click on **Add** button, select **Clone Repository...**  
> > 2.  On the **Clone a repository** pop-up window.  
> >     1.  Select the **GitHub.com** tab.  
> >         1.  In the **Filter** text box, enter the following text.  
> >             
> >             ```
> >             swagger-codegen
> >             ```  
> >             
> >         2.  Under **amzn**, select `swagger-api/swagger-codegen`.  
> >         3.  In the **Local path** test box, enter the following location.  
> >             *   Windows: `C:\third-party\git\swagger-codegen`  
> >     2.  Click on **Clone** button.  
> 


### Build swagger-codegen  

**bash**  
```bash  
cd /c/third-party/git/swagger-codegen
mvn clean package
```  -->  

## Download and Install Swagger Codegen  

The Swagger Codegen tool includes a Java command-line interface.  You must download and eitherinstall the swagger-codegen-cli.jar.  
You may either clone the [swagger-api/swagger-codegen GitHub repository](https://github.com/swagger-api/swagger-codegen) or [download a pre-built jar file from the Apache Maven site](#download-swagger-codegen-cli-from-apache-saven-site).  


### Download Swagger Codegen CLI from Apache Maven Site  

Download a prebuilt swagger-codegen-cli jar file from the Apache Maven packages.  
The local directory 

*   **For Posix users**  
    If you are running on Posix OS \(Linux, UNIX, or macOS\), use the following `wget` command to download the jar file for Swagger Codegen.  
    
    1.  Create a new directory named `swagger-codegen`.  
        
        > **bash**  
        > ```bash
        > mkdir /spds/downloads/swagger-codegen
        > ```  

    2.  Run th following `wget` command to download the `swagger-codegen-cli.jar` Java file.  
        
        > **bash**  
        > ```bash
        > wget http://central.maven.org/maven2/io/swagger/swagger-codegen-cli/2.4.5/swagger-codegen-cli-2.4.5.jar --output-document=/spds/downloads/swagger-codegen/swagger-codegen-cli.jar
        > ```  
    
    3.  Confirm that the `swagger-codegen` command works.  
        
        > **bash**  
        > ```bash
        > cd /spds/downloads/swagger-codegen
        > java -jar swagger-codegen-cli.jar help
        > ```  

*   **For Windows users**  
    If you are running on Windows \(using PowerShell 3.0 and newer\), use the following `Invoke-WebRequest` command in PowerShell (3.0+) to download the jar file for Swagger Codegen.  
    
    1.  Create a new directory named `swagger-codegen`.  
        
        > **powershell**  
        > ```powershell
        > New-Item -ItemType directory -Path C:\spds\downloads\swagger-codegen
        > ```  

    2.  Run th following `wget` command to download the `swagger-codegen-cli.jar` Java file.  
        
        > **powershell**  
        > ```powershell
        > Invoke-WebRequest http://central.maven.org/maven2/io/swagger/swagger-codegen-cli/2.4.5/swagger-codegen-cli-2.4.5.jar -OutFile C:\spds\downloads\swagger-codegen\swagger-codegen-cli.jar
        > ```  
    
    3.  Confirm that the `swagger-codegen` command works.  
        
        > **powershell**  
        > ```powershell
        > set-location C:\spds\downloads\swagger-codegen
        > Start-Process java -ArgumentList '-jar', 'swagger-codegen-cli.jar help'
        > ```  


### Add Swagger-codegen to PATH  

Add the location of the Swagger-codegen jar file to reduce the amount of typing for each use.  


*   **For Posix users**  
    > **bash**  
    > ```bash
    > export PATH="/spds/downloads/swagger-codegen;$PATH"
    > ```  

*   **For Windows users**  
    > **cmd**  
    > ```cmd
    > setx PATH "C:\spds\downloads\swagger-codegen\;%PATH%"
    > ```  


---  


## Create a Clone for the SP API Reference  

Save a copy of the Amazon SP API Models to your local machine.  


### Clone Octane Package for AMDSAPISwaggerModels  

Copy the URI of the AMDSAPISwaggerModels repository.  

In **Web browser**  
> 1.  Visit [code.amazon.com/packages/AMDSAPISwaggerModels](https://code.amazon.com/packages/AMDSAPISwaggerModels/trees/APIG) and copy the Clone uri.  
>     
>     ```
>     ssh://git.amazon.com/pkg/AMDSAPISwaggerModels
>     ```  


### Clone the repo into a local directory for SPDS API reference  

Use the repo location to create a copy on your local machine.  
You may clone the repo using bash, Windows cmd, or GitHub Desktop.  



*   **For Posix users**  
    1.  Create a new directory named `AMDSAPISwaggerModels`.  
        
        > **bash**  
        > ```bash
        > mkdir /spds/git/AMDSAPISwaggerModels
        > ```  

    2.  Run th following `git` command to clone the `AMDSAPISwaggerModels` GitFarm repository.  
        
        > **bash**  
        > ```bash
        > git clone ssh://git.amazon.com/pkg/AMDSAPISwaggerModels /spds/git/AMDSAPISwaggerModels
        > ```  
        
    3.  Run the following `git` command to view the main branch named `APIG`.  
        
        > **bash**  
        > ```bash
        > cd /spds/git/AMDSAPISwaggerModels 
        > git checkout APIG
        > ```  
        
*   **For Windows users**  
    1.  Create a new directory named `AMDSAPISwaggerModels`.  
        
        > **cmd**  
        > ```cmd
        > mkdir md C:\spds\git\AMDSAPISwaggerModels
        > ```  

    2.  Run th following `git` command to clone the `AMDSAPISwaggerModels` GitFarm repository.  
        
        > **cmd**  
        > ```cmd
        > clone ssh://git.amazon.com/pkg/AMDSAPISwaggerModels C:\spds\git\AMDSAPISwaggerModels
        > ```  
        
    3.  Run the following `git` command to view the main branch named `APIG`.  
        
        > **cmd**  
        > ```cmd
        > cd C:\spds\git\AMDSAPISwaggerModels 
        > git checkout APIG
        > ```  

*   In **Git Desktop**  
    > 1.  Clone a repository by choosing one of the following methods.  
    >     *   Select **File** > **Clone Repository...**  
    >     *   Press `Ctrl`+`Shift`+`O`  
    >     *   Click on **Current repository** button, click on **Add** button, select **Clone Repository...**  
    > 2.  On the **Clone a repository** pop-up window.  
    >     1.  Select the **URL** tab.  
    >         *   In the **Repository URl or GitHub username and repository** text box, enter the **Clone uri**. 
    >             
    >             ```
    >             ssh://git.amazon.com/pkg/AMDSAPISwaggerModels
    >             ```  
    >             
    >         *   In the **Local path** test box, enter the following location.  
    >             *   Posix: `/spds/git/AMDSAPISwaggerModels`  
    >             *   Windows: `C:\spds\git\AMDSAPISwaggerModels`  
    >     4.  Click on **Clone** button.  


---  


## Generate html from a  single JSON file  

Run the following `Java` command to locally generate `index.html` file from a Swagger JSON file.  

> **NOTE**: The output html file is always named `index`.  

> **shell**
> ```shell 
> java -jar swagger-codegen-cli.jar generate --lang html2 --input-spec "[file_name].json"
> ```  

> **EXAMPLE**  
> > **shell**
> > ```shell 
> > java -jar swagger-codegen-cli.jar generate --lang html2 --input-spec "sales.json"  
> > ```  


*   **For Posix users**  
    1.  Open the `swagger-models` directory.  
        
        > **bash**  
        > ```bash
        > cd "spds/git/AMDSAPISwaggerModels/swagger-models"
        > ```  

    2.  Run the `Java` command to generate the html file.  
        
        > **bash**  
        > ```bash
        > java -jar swagger-codegen-cli.jar generate --lang html2 --input-spec "sales.json"
        > ```  

    3.  Move and rename the html file.  
        
        > **bash**  
        > ```bash
        > mv "index.html" "/spds/_out/api_ref/sales.html"
        > ```  

    4.  Delete the temporary files.  
        
        > **bash**  
        > ```bash
        > rm -fr ".swagger-codegen"
        > rm -fr ".swagger-codegen-ignore"
        > ```  

*   **For Windows users**  
    1.  Open the `swagger-models` directory.  
        
        > **cmd**  
        > ```cmd
        > cd "/c/spds/git/AMDSAPISwaggerModels/swagger-models"
        > ```  

    2.  Run the `Java` command to generate the html file.  
        
        > **cmd**  
        > ```cmd
        > java -jar swagger-codegen-cli.jar generate --lang html2 --input-spec "sales.json"
        > ```  

    3.  Move and rename the html file.  
        
        > **cmd**  
        > ```cmd
        > move "index.html" "C:\spds\_out\api_ref\sales.html"
        > ```  

    4.  Delete the temporary files.  
        
        > **cmd**  
        > ```cmd
        > erase /FS ".swagger-codegen"
        > erase /FS ".swagger-codegen-ignore"
        > ```  


## Generate html for All JSON Files in a Directory  

The contents of the `spds-generate_html_from_json_directory.sh` script file.  

> **bash**
> ```bash
> # !/bin/bash
> 
> # sysinfo_page - A script to produce html for Swagger JSON
> ## Archive previous build and create new build directory
> 
> SPDS_MODEL_DIR="/c/spds/git/AMDSAPISwaggerModels/swagger-models"
> CODEGEN_DIR="/c/spds/downloads/swagger-codegen"
> SPDS_REF_BUILD_DIR="/c/spds/_out/api_ref"
> 
> if [ ! -d $SPDS_REF_BUILD_DIR ]; then
>    echo "Create $SPDS_REF_BUILD_DIR directory"
>    mkdir $SPDS_REF_BUILD_DIR
> fi
> 
> ## Copy JSON into directories 
> echo "=== Copy JSON into directories ==="
> for file in $SPDS_MODEL_DIR/*.json
> do
>     file_ext="$(basename "$file")"
>     file_sh="${file_ext%.*}"
>     if [ ! -d $SPDS_REF_BUILD_DIR/$file_sh ]; then
>         echo "Create $SPDS_REF_BUILD_DIR/$file_sh directory"
>         mkdir $SPDS_REF_BUILD_DIR/$file_sh
>     fi    
>     echo "$file_ext --> $SPDS_REF_BUILD_DIR/$file_sh/$file_ext"
>     cp -f "$file" "$SPDS_REF_BUILD_DIR/$file_sh/$file_ext"
> done
> 
> ## Run code gen for all json in directory  
> echo "== Generate html from JSON =="
> for file in $SPDS_MODEL_DIR/*.json
> do
>     file_ext="$(basename "$file")"
>     file_sh="${file_ext%.*}"
>     java -jar $CODEGEN_DIR/swagger-codegen-cli.jar generate --lang html2 --input-spec "$file" --output "$SPDS_REF_BUILD_DIR"
>     echo "$file_ext --> $SPDS_REF_BUILD_DIR/$file_sh/$file_sh.html"
>     mv -f "$SPDS_REF_BUILD_DIR/index.html" "$SPDS_REF_BUILD_DIR/$file_sh/$file_sh.html"
> done
> 
> echo "==============================="
> 
> ## Delete the temporary files
> rm -fr "$SPDS_REF_BUILD_DIR/.swagger-codegen"
> rm -fr "$SPDS_REF_BUILD_DIR/.swagger-codegen-ignore"
> rm -fr "$SPDS_REF_BUILD_DIR/index.html"
> ```  

The contents of the `spds-generate_html_from_json_directory.bat` batch file.  

> **cmd**
> ```cmd
> @echo off
> 
> REM Archive previous build and create new build directory
> set SPDS_MODEL_DIR=C:\spds\git\AMDSAPISwaggerModels\swagger-models
> set CODEGEN_DIR=C:\spds\downloads\swagger-codegen
> set SPDS_REF_BUILD_DIR=C:\spds\_out\api_ref
> 
> if NOT EXIST %SPDS_REF_BUILD_DIR% ( echo "Create %SPDS_REF_BUILD_DIR% directory" && mkdir %SPDS_REF_BUILD_DIR% )
> 
> REM Copy all json in named directories  
> echo === Copy JSON into directories ===
> FOR /R %SPDS_MODEL_DIR% %%i in (*.json) DO (
>     echo %%~ni.json --> %SPDS_REF_BUILD_DIR%\%%~ni\%%i
>     if NOT EXIST %SPDS_REF_BUILD_DIR%\%%~ni\ ( echo "Create %SPDS_REF_BUILD_DIR%\%%~ni directory" && mkdir %SPDS_REF_BUILD_DIR%\%%~ni\ )
>     COPY %%i %SPDS_REF_BUILD_DIR%\%%~ni\
> )
> 
> REM Run code gen for all json in directory
> echo == Generate html from JSON ==
> FOR /R %SPDS_MODEL_DIR% %%i in (*.json) DO (
>     java -jar %CODEGEN_DIR%\swagger-codegen-cli.jar generate --lang html2 --input-spec "%%i" --output "%SPDS_REF_BUILD_DIR%"
>     echo %%~ni.json --> %SPDS_REF_BUILD_DIR%\%%~ni\%%~ni.html
>     move /Y "%SPDS_REF_BUILD_DIR%\index.html" "%SPDS_REF_BUILD_DIR%\%%~ni\%%~ni.html"
> )
> echo ===============================
> 
> REM Delete the temporary files
> if EXIST "%SPDS_REF_BUILD_DIR%\.swagger-codegen" ( del /F /S /Q "%SPDS_REF_BUILD_DIR%\.swagger-codegen" )
> if EXIST "%SPDS_REF_BUILD_DIR%\.swagger-codegen-ignore" ( del /F /S /Q "%SPDS_REF_BUILD_DIR%\.swagger-codegen-ignore" )
> if EXIST "%SPDS_REF_BUILD_DIR%\index.html" ( del /F /S /Q "%SPDS_REF_BUILD_DIR%\index.html" )
> 
> REM Delete the temporary directories
> if EXIST "%SPDS_REF_BUILD_DIR%\.swagger-codegen\" ( rd /S /Q "%SPDS_REF_BUILD_DIR%\.swagger-codegen" )
> if EXIST "%SPDS_REF_BUILD_DIR%\.swagger-codegen-ignore\" ( rd /S /Q "%SPDS_REF_BUILD_DIR%\.swagger-codegen-ignore" )
> ```  
