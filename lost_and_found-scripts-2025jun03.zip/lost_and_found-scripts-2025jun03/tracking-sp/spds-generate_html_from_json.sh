## Archive previous build and create new build directory

BUILD_DIR="/c/spds/outfile/build`date '+%Y_%m_%d__%H_%M_%S'`"

mkdir $BUILD_DIR

## Change directory to target directory for output  

cd "/c/spectrum/git/AMDSAPISwaggerModels/swagger-models"

## Run code gen for all json in directory  

for file in *.json
do
    java -jar "/c/spectrum/git/swagger-codegen-cli.jar" generate -l html2 -i "$file"
    mv "index.html" "$BUILD_DIR/$file.html"
done

rm -fr ".swagger-codegen"
rm -fr ".swagger-codegen-ignore"