export SP_HOME="/c/spds"
export SP_BUILD_TOOLS_HOME="$SP_HOME/git/SPDSDocumentationBuild"
export SP_DITA_DIR="$SP_BUILD_TOOLS_HOME/dita-ot-3.3"
export SPUS="$SP_HOME/git/SPDSDocumentation-en_US"
export SPJP="$SP_HOME/git/SPDSDocumentation-ja_JP"
export SPBR="$SP_HOME/git/SPDSDocumentation-pt_BR"
export SPTR="$SP_HOME/git/SPDSDocumentation-tr_TR"
export SPCN="$SP_HOME/git/SPDSDocumentation-zh_CN"
export OUTPUT_HOME="$SP_HOME/_out"
export XHTML_HOME="$OUTPUT_HOME/xhtml/spapi"
export PATH="$SP_DITA_DIR/bin;$PATH"

rm -fr "$XHTML_HOME/*"

$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_AU.ditaval --format=xhtml --output=$XHTML_HOME/en_AU/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_CA.ditaval --format=xhtml --output=$XHTML_HOME/en_CA/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_DE.ditaval --format=xhtml --output=$XHTML_HOME/en_DE/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_ES.ditaval --format=xhtml --output=$XHTML_HOME/en_ES/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_FR.ditaval --format=xhtml --output=$XHTML_HOME/en_FR/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_IN.ditaval --format=xhtml --output=$XHTML_HOME/en_IN/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_IT.ditaval --format=xhtml --output=$XHTML_HOME/en_IT/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_MX.ditaval --format=xhtml --output=$XHTML_HOME/en_MX/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_UK.ditaval --format=xhtml --output=$XHTML_HOME/en_UK/
$SP_DITA_DIR/bin/dita --input=$SPUS/HTML_EN.ditamap --filter=$SPUS/HTML_US.ditaval --format=xhtml --output=$XHTML_HOME/en_US/
$SP_DITA_DIR/bin/dita --input=$SPJP/HTML_JP.ditamap --filter=$SPJP/HTML_JP.ditaval --format=xhtml --output=$XHTML_HOME/ja_JP/
$SP_DITA_DIR/bin/dita --input=$SPBR/HTML_BR.ditamap --filter=$SPBR/HTML_BR.ditaval --format=xhtml --output=$XHTML_HOME/pt_BR/
$SP_DITA_DIR/bin/dita --input=$SPTR/HTML_TR.ditamap --filter=$SPTR/HTML_TR.ditaval --format=xhtml --output=$XHTML_HOME/tr_TR/
$SP_DITA_DIR/bin/dita --input=$SPCN/HTML_CN.ditamap --filter=$SPCN/HTML_CN.ditaval --format=xhtml --output=$XHTML_HOME/zh_CN/