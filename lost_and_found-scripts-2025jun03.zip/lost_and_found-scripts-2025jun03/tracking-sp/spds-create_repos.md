# Create Repositories  

**Contents**  
*   [Create SPDS Build repo](#create-spds-build-repo)  
    *   [Create new Octane Package for SPDS Build](#create-new-octane-package-for-spds-build)  
    *   [Clone Octane Package for SPDS Build](#clone-octane-package-for-spds-build)  
        *   [Create directory on your local Windows machine for SPDS Build](#create-directory-on-your-local-windows-machine-for-spds-build)  
        *   [Clone the repo into a local directory for SPDS Build](#clone-the-repo-into-a-local-directory-for-spds-build)  
*   [Download and install Java, OpenJDK, or Amazon Corretto](#download-and-install-java-openjdk-or-amazon-corretto)  
*   [Download and add DITA-OT to build repo](#download-and-add-dita-ot-to-build-repo)  
    *   [Download latest DITA-OT](#download-latest-dita-ot)  
    *   [Copy DITA-OT contents into repo](#copy-dita-ot-contents-into-repo)  
    *   [Push content to Octane Package](#push-content-to-octane-package)  
    *   [Add DITA-OT binary directory to Windows environment variable path](#add-dita-ot-binary-directory-to-windows-environment-variable-path)  
    ---
*   [Create SPDS/SP API Doc repo for en_US](#create-spds/sp-api-doc-repo-for-en_US)  
    *   [Create new Octane Package for en_US](#create-new-octane-package-for-en_US)  
    *   [Clone Octane Package for en_US](#clone-octane-package-for-en_US)  
        *   [Create directory on your local Windows machine for en_US](#create-directory-on-your-local-windows-machine-for-en_US)  
        *   [Clone the repo into a local directory for en_US](#clone-the-repo-into-a-local-directory-for-en_US)  
*   [Download and copy markdown version of dev guide to en_US](#download-and-copy-markdown-version-of-dev-guide-to-en_US)  
    *   [Clone the repo into a local directory for GitHub](#clone-the-repo-into-a-local-directory-for-github)  
    *   [Add existing markdown file into SPDS repo for en_US](#add-existing-markdown-file-into-spds-repo-for-en_US)  
    *   [Push content to Octane Package for en_US](#push-content-to-octane-package-for-en_US)  
*   [Create new ditamap file for the markdown](#create-new-ditamap-file-for-the-markdown)  
*   [Separate DITA content into individual topics](#separate-dita-content-into-individual-topics)  
*   [Clean up DITA topics](#clean-up-dita-topics)  
*   [Build output using DITA-OT](#build-output-using-dita-ot)  
    *   [Create plugin for building xhtml](#create-plugin-for-building-xhtml)  
    *   [Create plugin for building pdf](#create-plugin-for-building-pdf)  
    *   [Use dita command to build github-flavored markdown](#use-dita-command-to-build-github-flavored-markdown)  
    *   [Use dita command to build html5](#use-dita-command-to-build-html5)  
    *   [Use dita command to build xhtml](#use-dita-command-to-build-xhtml)  
*   [Set Windows Environment Variables](#set-windows-environment-variables)  


---  


## Create SPDS Build repo  


### Create new Octane Package for SPDS Build  

> **Web browser**  
> 
> > 1. Visit [code.amazon.com](https:/code.amazon.com) and create new Octane Package.  
> > 
> > 2.  Under **I want to create**.  
> >     *   Click on **Default \(Empty\) Package**.  
> > 3.  **Package Name**: `SPDSDocumentationBuild`  
> > 4.  **Description**: `The build package for the SPDS documentation based upon DITA-OT.`  
> > 5.  **Permission Type**  
> >     1.  Click on **Use Bindles**.  
> >     2.  Select `SpectrumCM`  
> > 6.  **Package Permissions**  
> >     *   Click on **Public source, Public artifacts, Buildable**.  
> > 7.  Click on **Create** button.  


### Clone Octane Package for SPDS Build  

> **Web browser**  
> 
> > 1.  Visit [code.amazon.com/packages/SPDSDocumentationBuild/trees/mainline](https://code.amazon.com/packages/SPDSDocumentationBuild/trees/mainline) and copy the Clone uri.  
> > 
> > ```
> > ssh://git.amazon.com/pkg/SPDSDocumentationBuild
> > ```  


#### Create directory on your local Windows machine for SPDS Build

> **bash**  
> 
> > ```bash
> > mkdir /c/spds/git/SPDSDocumentationBuild
> > ```  
> 
> **cmd**  
>  
> > ```
> > md C:\spds\git\SPDSDocumentationBuild
> > ```  


#### Clone the repo into a local directory for SPDS Build  

> **git bash**  
> 
> > ```  
> > git clone ssh://git.amazon.com/pkg/SPDSDocumentationBuild /c/spds/git/SPDSDocumentationBuild
> >
> > chdir /c/spds/git/SPDSDocumentationBuild
> > 
> > git checkout mainline
> > ```  
> **git via cmd**  
> 
> > ```  
> > git clone ssh://git.amazon.com/pkg/SPDSDocumentationBuild C:\spds\git\SPDSDocumentationBuild
> >
> > cd C:\spds\git\SPDSDocumentationBuild
> > 
> > git checkout mainline
> > ```  
> **Git Desktop**  
> 
> > 1.  Clone a repository by choosing one of the following methods.  
> >     *   Select **File** > **Clone Repository...**  
> >     *   Press `Ctrl`+`Shift`+`O`  
> >     *   Click on **Current repository** button, click on **Add** button, select **Clone Repository...**  
> > 2.  On the **Clone a repository** pop-up window.  
> >     1.  Select the **URL** tab.  
> >         *   In the **Repository URl or GitHub username and repository** text box, enter the **Clone uri**. 
> >             
> >             ```
> >             ssh://git.amazon.com/pkg/SPDSDocumentationBuild
> >             ```  
> >             
> >         *   In the **Local path** test box, enter the following location.  
> >             *   Windows: `C:\spds\git\SPDSDocumentationBuild`  
> >     2.  Click on **Clone** button.  
> 


---  





---  


## Download and add DITA-OT to build repo  


### Download latest DITA-OT  

> **Web browser**  
> 
> > 1.  Download [DITA-OT 3.3](https://www.dita-ot.org/download)  
> >     *   Windows cmd: `C:\downloads\dita-ot-3.3.zip`  
> > 2.  Extract contents of .zip archive file.  
> >     *   Windows bash: `/c/downloads/dita-ot-3.3/dita-ot-3.3`  
> >     *   Windows cmd: `C:\downloads\dita-ot-3.3\dita-ot-3.3`  


### Copy DITA-OT contents into repo  

> **bash**  
>   
> > ```bash
> > cp -R /c/downloads/dita-ot-3.3/dita-ot-3.3 /c/spds/git/SPDSDocumentationBuild/dita-ot-3.3
> > ```  
> >
> **cmd**  
>   
> > ```
> > xcopy /E /I C:\downloads\dita-ot-3.3\dita-ot-3.3/*.* C:\spds\git\SPDSDocumentationBuild\dita-ot-3.3
> > ```  


### Push content to Octane Package  

> **git bash**  
> 
> > ```  
> > chdir /c/spds/git/SPDSDocumentationBuild 
> > git push
> > ```  
> **git via cmd**  
> 
> > ```  
> > cd C:\spds\git\SPDSDocumentationBuild
> > git push
> > ```  


### Add DITA-OT binary directory to Windows environment variable path  

> **cmd**  
> 
> > ```
> > set PATH=C:\spds\git\SPDSDocumentationBuild\dita-ot-3.3\bin;%PATH%
> > ```  


---  


## Create SPDS/SP API Doc repo for en_US  


### Create new Octane Package for en_US  

> **Web browser**  
> 
> > 1.  Visit [code.amazon.com](https:/code.amazon.com) and create new Octane Package.  
> >
> > 2.  Under **I want to create**.  
> >     *   Click on **Default \(Empty\) Package**.  
> > 3.  **Package Name**: `SPDSDocumentation-en_US`  
> > 4.  **Description**: `The SPDS documentation package for en_US.`  
> > 5.  **Permission Type**  
> >     1.  Click on **Use Bindles**.  
> >     2.  Select `SpectrumCM`  
> > 6.  **Package Permissions**  
> >     *   Click on **Public source, Public artifacts, Buildable**.  
> > 7.  Click on **Create** button.  


### Clone Octane Package for en_US  

> **Web browser**  
> 
> 1.  Visit [code.amazon.com/packages/SPDSDocumentation-en_US/trees/mainline](https://code.amazon.com/packages/SPDSDocumentation-en_US/trees/mainline) and copy the Clone uri.  
>
> > ```
> > ssh://git.amazon.com/pkg/SPDSDocumentationBuild
> > ```  


#### Create directory on your local Windows machine for en_US

> **bash**  
> 
> > ```bash
> > mkdir /c/spds/git/SPDSDocumentation-en_US
> > ```  
> 
> **cmd**  
>  
> > ```
> > md C:\spds\git\SPDSDocumentation-en_US
> > ```  


#### Clone the repo into a local directory for en_US  

> **git bash**  
> 
> > ```  
> > git clone ssh://git.amazon.com/pkg/SPDSDocumentation-en_US /c/spds/git/SPDSDocumentation-en_US
> >
> > chdir /c/spds/git/SPDSDocumentation-en_US
> > 
> > git checkout mainline
> > ```  
> **git via cmd**  
> 
> > ```  
> > git clone ssh://git.amazon.com/pkg/SPDSDocumentation-en_US C:\spds\git\SPDSDocumentation-en_US
> >
> > cd C:\spds\git\SPDSDocumentation-en_US
> > 
> > git checkout mainline
> > ```  
> **Git Desktop**  
> 
> > 1.  Clone a repository by choosing one of the following methods.  
> >     *   Select **File** > **Clone Repository...**  
> >     *   Press `Ctrl`+`Shift`+`O`  
> >     *   Click on **Current repository** button, click on **Add** button, select **Clone Repository...**  
> > 2.  On the **Clone a repository** pop-up window.  
> >     1.  Select the **URL** tab.  
> >         *   In the **Repository URl or GitHub username and repository** text box, enter the **Clone uri**. 
> >             
> >             ```
> >             ssh://git.amazon.com/pkg/SPDSDocumentation-en_US
> >             ```  
> >             
> >         *   In the **Local path** test box, enter the following location.  
> >             *   Windows: `C:\spds\git\SPDSDocumentation-en_US`  
> >     2.  Click on **Clone** button.  
> 


---  


## Download and copy markdown version of dev guide to en_US  


### Clone the repo into a local directory for github 

> **git bash**  
> 
> > ```  
> > git clone https://github.com/amzn/amazon-marketplace-api-sdk.git /c/spds/git/amazon-marketplace-api-sdk
> >
> > chdir /c/spds/git/amazon-marketplace-api-sdk
> > 
> > git checkout master
> > ```  
> **git via cmd**  
> 
> > ```  
> > git clone https://github.com/amzn/amazon-marketplace-api-sdk.git C:\spds\git\amazon-marketplace-api-sdk
> >
> > cd C:\spds\git\amazon-marketplace-api-sdk
> > 
> > git checkout master
> > ```  
> **Git Desktop**  
> 
> > 1.  Clone a repository by choosing one of the following methods.  
> >     *   Select **File** > **Clone Repository...**  
> >     *   Press `Ctrl`+`Shift`+`O`  
> >     *   Click on **Current repository** button, click on **Add** button, select **Clone Repository...**  
> > 2.  On the **Clone a repository** pop-up window.  
> >     1.  Select the **GitHub.com** tab.  
> >         1.  In the **Filter** text box, enter the following text.  
> >             
> >             ```
> >             amazon-marketplace-api-sdk
> >             ```  
> >             
> >         2.  Under **amzn**, select `amzn/amazon-marketplace-api-sdk`.  
> >         3.  In the **Local path** test box, enter the following location.  
> >             *   Windows: `C:\spds\git\SPDSDocumentation-en_US`  
> >     2.  Click on **Clone** button.  
> 


### Add existing markdown file into SPDS repo for en_US 

> **bash**  
>   
> > ```bash
> > cp -R /c/spds/git/amazon-marketplace-api-sdk/developer-guide/spds-marketplace_api-dev_guide-alpha.md /c/spds/git/SPDSDocumentation-en_US/sourceForImport
> > ```  
> >
> **cmd**  
>   
> > ```
> > xcopy /E /I C:\spds\git\amazon-marketplace-api-sdk\developer-guide\spds-marketplace_api-dev_guide-alpha.md C:\spds\git\SPDSDocumentation-en_US\sourceForImport
> > ```  


### Push content to Octane Package for en_US 

> **git bash**  
> 
> > ```  
> > chdir /c/spds/git/SPDSDocumentation-en_US
> > git push
> > ```  
> **git via cmd**  
> 
> > ```  
> > cd C:\spds\git\SPDSDocumentation-en_US
> > git push
> > ```  


---  


## Create new ditamap file for the markdown  

> **In Oxygen**  
>
> > 1.  Create a new .ditamap file in the `/c/spds/git/SPDSDocumentation-en_US/sourceForImport` directory named `markdown_to_dita.ditamap`  
> > 2.  Open the ditamap file as text and paste the following text.  
> >     
> >     ```xml
> >     <?xml version="1.0" encoding="UTF-8"?>
> >     <!DOCTYPE map PUBLIC "-//OASIS//DTD DITA Map//EN" "map.dtd">
> >     <map>
> >         <topicref href="./spds-marketplace_api-dev_guide-alpha.md" format="markdown"/>
> >     </map>
> >     ```  
> > 3.  Save the ditamap file.  
> > 4.  In the **Dita Maps Manager**
> >     1.  Open `markdown_to_dita.ditamap`.  
> > 5.  Click on `spds-marketplace_api-dev_guide-alpha.md`.  
> > 6.  Click on **Document** \> **Source** \> **Export as DITA topic**.  
> > 7.  Save the new DITA topic to `/c/spds/git/SPDSDocumentation-en_US/developer_guide`.   


---  


## Separate DITA content into individual topics  

> **In Oxygen**  
>
> > 1.  Create a new .ditamap file in the `/c/spds/git/SPDSDocumentation-en_US/developer_guide` directory named `amazon_sp_api_dev_guide_en_us.ditamap`  
> > 2.  Open the ditamap file as text and paste the following text.  
> >     
> >     ```xml
> >     <?xml version="1.0" encoding="UTF-8"?>
> >     <!DOCTYPE map PUBLIC "-//OASIS//DTD DITA Map//EN" "map.dtd">
> >     <map id="DG_dita_map" title="Amazon Marketplace API Developer Guide: Alpha">
> >         <topicmeta>
> >             <author type="creator">[creator_name]</author>
> >             <copyright>
> >                 <copyryear year="2019"/>
> >                 <copyrholder>Amazon.com, Inc. or its affiliates</copyrholder>
> >             </copyright>
> >             <critdates>
> >                 <created date="[created_date]"/>
> >                 <revised modified="[current_date]"/>
> >             </critdates>
> >             <audience type="developer"/>
> >             <prodinfo>
> >                 <prodname>Amazon Marketplace API</prodname>
> >                 <vrmlist>
> >                     <vrm version="Alpha" release="2"/>
> >                 </vrmlist>
> >                 <component>Amazon Marketplace API Developer Guide</component>
> >             </prodinfo>
> >         </topicmeta>
> >         <topicref format="dita" href="./amazon_sp_api-dev_guide.dita" navtitle="Document History" type="topic" scope="local"/>
> >     </map>
> >     ```  
> > 3.  Save the ditamap file.  
> > 4.  In the **Dita Maps Manager**
> >     1.  Open `amazon_sp_api_dev_guide_en_us.ditamap`.  
> > 5.  Click on `amazon_sp_api-dev_guide.dita`.  
> > 6.  Manually separate each topic in the dita file into individual DITA files.  
> > 7.  Attach individual dita files to ditamap.  


---  


## Clean up DITA topics  

> **In Oxygen**  
>
> > 1.  Replace internal links with dita xrefs.  
> >     *   Match links to dita file names.  
> >     *   Change format from `html` \(or *whatever*\) to `dita`.  
> > 2.  Move code samples into individual files.  
> >     *   Create files in examples directory for each code example.  
> >     *   Attached code example to topic.  
> > 3.  Clean up notes.  
> >     *   Replace *notes* with **notes**.  
> >     *   Replace *important* with **notes** `type` **important**.  
> 


---  


## Build output using DITA-OT  


### Create plugin for building xhtml  

> **NOTE**: Work in progress  


### Create plugin for building pdf  

> **NOTE**: Work in progress  


### Use dita command to build github-flavored markdown  

> **bash**  
>
> ```bash
> dita --input=/c/spds/git/SPDSDocumentation-en_US/sp_api_root.ditamap --format=markdown_github --output=/c/spds/_out/gh-md/
> ```  


### Use dita command to build pdf  

> **bash**  
> 
> ```bash  
> dita --input=/c/spds/git/SPDSDocumentation-en_US/sp_api_root.ditamap --format=pdf --output=/c/spds/_out/pdf/
> ```  


### Use dita command to build html5  

> **bash**  
> 
> ```bash  
> dita --input=/c/spds/git/SPDSDocumentation-en_US/sp_api_root.ditamap --format=html5 --output=/c/spds/_out/html5/
> ```  


### Use dita command to build xhtml  

> **bash**  
> 
> ```bash  
> dita --input=/c/spds/git/SPDSDocumentation-en_US/sp_api_root.ditamap --format=xhtml --output=/c/spds/_out/xhtml/
> ```  


---  


## Set Windows Environment Variables  


### SPDS Build Home  

> **cmd**  
> ```
> set SPDS_BUILD_TOOLS_HOME=C:\spds\git\SPDSDocumentationBuild
> ```  


### SPDS Build for html Home  

> **cmd**  
> ```
> set SPDS_BUILD_HTML_HOME=C:\spds\output\html
> ```  


### AWS Cloudsearch CLI Home  

> **cmd**  
> ```
> set CS_HOME=%SPDS_BUILD_TOOLS_HOME%\CloudSearch\v2011-02-01
> ```  


### DITA Home  

> **cmd**  
> ```
> set DITA_DIR=%SPDS_BUILD_TOOLS_HOME%\DITA-OT1.8.5\
> ```  


### PuTTY Home  

> **cmd**  
> > **NOTE**: Required for using Cloudsearch.  
>
> ```
> set GIT_SSH=%ProgramFiles%\PuTTY\plink.exe
> ```  


### JAVA Home  

> **NOTE**: Use only one JDK at a time.  


#### Oracle Java Home

> **cmd**  
> ```
> set JAVA_HOME=%ProgramFiles%\Java\jdk1.8.0_191
> ```  


#### OpenJDK Home

> **cmd**  
> ```
> 
> ```  


#### Amazon Corretto Home  

> **cmd**  
> ```
> set JAVA_HOME=%ProgramFiles%\Amazon Corretto\jdk1.8.0_201
> ```  


### Python Home  

> **NOTE**: Use only one Python version at a time.  


#### Python 2.7  

> **cmd**  
> ```
> set PYTHONHOME=C:\Python27
> ```  


#### Python 3.7  

> **cmd**  
> ```
> set PYTHONHOME=C:\Python37
> ```  


### Windows local directories for SPDS repos  
 
> > **SPDS ROOT**  
> > **cmd**  
> > ```
> > set SPDS_HOME=C:\spds
> > ```  
>
> > **SPDS en_US local repo**  
> > **cmd**  
> > ```
> > set SPDS-en_US=%SPDS_HOME%/git/SPDSDocumentation-en_US
> > ```  
>
> > **SPDS ja_JP local repo**  
> > **cmd**  
> > ```
> > set SPDS-ja_JP=%SPDS_HOME%/git/SPDSDocumentation-ja_JP
> > ```  
>
> > ***SPDS zh_CN local repo**  
> > **cmd**  
> > ```
> > set SPDS_zh_CN=%SPDS_HOME%/git/SPDSDocumentation-zh_CN
> > ```  
>
