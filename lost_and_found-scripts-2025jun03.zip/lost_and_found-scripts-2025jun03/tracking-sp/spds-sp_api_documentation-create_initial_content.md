# Amazon Selling Partner API Documentation  

**SUBTITLE**: ***Create Initial Content***  

The Amazon Selling Partner API \(Amazon SP API\), formerly known as Marketplace API and SPDS API, is the next generation control plane that works with Amazon Marketplace Web Service (Amazon MWS).  

The Amazon SP API documentation leverages the structures from the Amazon MWS documentation.  
The build directory and the source documentation directories are version controlled using git to synchronize with Amazon GitFarm repositories.  


The following content describes the settings of the initial tools and ongoing requirements.  

**Contents**  
*   [Intended Audience](#intended-audience)  
*   [Requirements](#requirements)  
*   [Prerequisites](#prerequisites)  
    *   [Permissions](#permissions)  
    *   [Software](#software)  
*   [Reusable Variables](#reusable-variables)  
*   [Create Empty Repositories](#create-empty-repositories)  
*   [Clone Repositories](#clone-repositories)  
    *   [Copy URI](#copy-uri)  
    *   [Use Git to Clone Repositories](#use-git-to-clone-repositories)  
*   [Add Initial Content to Build Repository](#add-initial-content-to-build-repository)  
    *   [Download Latest DITA-OT](#download-latest-dita-ot)  
    *   [Copy DITA-OT into Build Repository](#copy-dita-ot-into-build-repository)  
*   [Add Initial Content to Documentation Repositories](#add-initial-content-to-documentation-repositories)  
    *   [Migrate GitHub Markdown into English Repository](#migrate-github-markdown-into-english-repository)  
        *   [Clone the Private Repository into a Local Directory](#clone-the-private-repository-into-a-local-directory)  
        *   [Copy Markdown into local English Directory](#copy-markdown-into-local-english-directory)  
        *   [Create a Ditamap File for the Markdown](#create-a-ditamap-file-for-the-markdown)  
        *   [Separate DITA Content into Individual Topics](#separate-dita-content-into-individual-topics)  
        *   [Clean DITA Topics](#clean-dita-topics)  
*   [Replicate Content](#replicate-content)
    *   [Copy English Repository to Other Languages](#copy-english-repository-to-other-languages)  
    *   [Translate Other Language Repositories](#translate-other-language-repositories)  
*   [Save Changes to Repository](#save-changes-to-repository)  

---  


## Intended Audience  

*   SDE 1+  
*   Technical Writer  
*   Business Owner  


## Requirements  

*  Successfully create build repository and migrate markdown into DITA.  


## Prerequisites  

In order to access, set up, and modify the Amazon SP API documentation.  


### Permissions  

You must have access to [github.com/amzn/amazon-marketplace-api-sdk](https://github.com/amzn/amazon-marketplace-api-sdk).  
You must have access to [code.amazon.com](https://code.amazon.com).  
You must have access to the `SpectrumCM` bindle.  


### Software  

You must install at least one package for each tool listed below.  

| Tool | Package | Download |  
|:--- |:--- |:--- |  
| AWS | AWS CLI 64-bit | [aws.amazon.com/cli](https://aws.amazon.com/cli) |  
| Git | git-scm 64-bit | [git-scm.com/downloads](https://git-scm.com/downloads) |  
| Git | GitHub Desktop 64-bit | [desktop.github.com](https://desktop.github.com) |  
| JDK | Amazon Corretto JDK 64-bit | [aws.amazon.com/corretto](https://aws.amazon.com/corretto) |  
| JDK | OpenJDK 64-bit | [openjdk.java.net/install](https://openjdk.java.net/install) |  
| JDK | Oracle Java JDK 64-bit | [www.oracle.com/technetwork/es/java/javasebusiness/downloads](https://www.oracle.com/technetwork/es/java/javasebusiness/downloads) |  


## Reusable Variables  

The following variables reduce the amount of typing and ensure consistency in your day-to-day use.  

*   On Posix \(GNU/linux, macOS, UNIX\)  
    Use the following command to set the variables.  
    
    ```bash
    export [variable_name]=[value]
    ```  
    
    | Variable | Value |  
    |:--- |:--- |  
    | BUILD_TOOLS_HOME | `/mws/git/build_tools` |  
    | BUILD_HTML_HOME | `$BUILD_TOOLS_HOME/build_html` |  
    | DITA_DIR | `$BUILD_TOOLS_HOME/DITA-OT1.8.5` |  
    | GIT_SSH | [location of your ssh] |  
    | JAVA_HOME | [location of your jdk] |  
    | SP_HOME | `/spds` |  
    | SP_BUILD_TOOLS_HOME | `$SP_HOME/git/SPDSDocumentationBuild` |  
    | SP_DITA_DIR | `$SP_BUILD_TOOLS_HOME/dita-ot-3.3` |  
    | SPUS | `$SP_HOME/git/SPDSDocumentation-en_US` |  
    | SPJP | `$SP_HOME/git/SPDSDocumentation-ja_JP` |  
    | SPBR | `$SP_HOME/git/SPDSDocumentation-pt_BR` |  
    | SPTR | `$SP_HOME/git/SPDSDocumentation-tr_TR` |  
    | SPCN | `$SP_HOME/git/SPDSDocumentation-zh_CN` |  
    | PATH | `$SP_DITA_DIR\bin;$PATH​` |   
    
    
*   On Windows  
    *   Use the following command to set the variables on the **Command Prompt**.  
        
        ```cmd
        setx [variable_name] [value]
        ```  

    *   Use the following command to set the variables on the **Powershell**.  
        
        ```powershell
        $Env:[variable_name]="[value]"
        ```  
    
    | Variable | Value |  
    |:--- |:--- |  
    | BUILD_TOOLS_HOME | `C:\mws\git\build_tools` |  
    | BUILD_HTML_HOME | `%BUILD_TOOLS_HOME%\build_html` |  
    | DITA_DIR | `%BUILD_TOOLS_HOME%\DITA-OT1.8.5` |  
    | GIT_SSH | [location of your PuTTY executable] |  
    | JAVA_HOME | [location of your jdk] |  
    | SP_HOME | `C:\spds` |  
    | SP_BUILD_TOOLS_HOME | `%SP_HOME%\git\SPDSDocumentationBuild` |  
    | SP_DITA_DIR |` %SP_BUILD_TOOLS_HOME%\dita-ot-3.3` |  
    | SPUS | `%SP_HOME%\git\SPDSDocumentation-en_US` |  
    | SPJP | `%SP_HOME%\git\SPDSDocumentation-ja_JP` |  
    | SPBR | `%SP_HOME%\git\SPDSDocumentation-pt_BR` |  
    | SPTR | `%SP_HOME%\git\SPDSDocumentation-tr_TR` |  
    | SPCN | `%SP_HOME%\git\SPDSDocumentation-zh_CN` |  
    | PATH | `%SP_DITA_DIR%\bin;%PATH%​` |  


## Create Empty Repositories  

This is a one-time task for build and each of the content languages.  
Each repository is an Octane package that resides in the Amazon GitFarm.  

In your **Web browser**, perform the following tasks.  
1.  On the [Code Browser : Code Dashboard](https://code.amazon.com) page
    1.  In the bottom-left corner, under **Packages**, click on [Create Package](https://octane.amazon.com/package) link
2.  On the [Octane : Create a new Octane Package](https://octane.amazon.com/package) page  
    1.  Under **I want to create**, select the `Default (Empty) Package` radio button  
    2.  In **Package Name** text box, enter the package name.  
    3.  In **Description** test box, enter the description.  
    4.  Under **Permission Type**  
        1.  Select the `Use Bindles` radio button  
        2.  Select `SpectrumCM` from the drop-down menu  
    5.  Under **Package Permissions**, select the `Public source, Public artifacts, Buildable` radio button  
    6.  Click on **Create** button  

After completing this task for each package, you have the following empty repositories on GitFarm.  

|  | Package Name | Description | GitFarm Location |  
|:--- |:--- |:--- |:--- |  
| SP API Build | `SPDSDocumentationBuild` | `The build package for the SPDS documentation based upon DITA-OT.` | [code.amazon.com/packages/SPDSDocumentationBuild](https://code.amazon.com/packages/SPDSDocumentationBuild) |  
| English | `SPDSDocumentation-en_US` | `The SPDS documentation package for en_US.` | [code.amazon.com/packages/SPDSDocumentation-en_US]([https://code.amazon.com/packages/SPDSDocumentation-en_US) |  
| Japanese | `SPDSDocumentation-ja_JP` | `The SPDS documentation package for ja_JP.` | [code.amazon.com/packages/SPDSDocumentation-ja_JP](https://code.amazon.com/packages/SPDSDocumentation-ja_JP) |  
| Portuguese | `SPDSDocumentation-pt_BR` | `The SPDS documentation package for pt_BR.` | [code.amazon.com/packages/SPDSDocumentation-pt_BR](https://code.amazon.com/packages/SPDSDocumentation-pt_BR) |  
| Turkish | `SPDSDocumentation-tr_TR` | `The SPDS documentation package for tr_TR.` | [code.amazon.com/packages/SPDSDocumentation-tr_TR](https://code.amazon.com/packages/SPDSDocumentation-tr_TR) |  
| Chinese | `SPDSDocumentation-zh_CN` | `The SPDS documentation package for zh_CN.` | [code.amazon.com/packages/SPDSDocumentation-zh_CN](https://code.amazon.com/packages/SPDSDocumentation-zh_CN) |  


## Clone Repositories  

For each machine, you must repeat the following steps to access the GitFarm repositories and create local copies.  This step in required is you plane to review, edit, or build the Amazon SP API documentation.  
Due to style compatibility, the html output is built using a modified branch of the MWS Build repository.  The markdown output is built using the SP API build repository.  


### Copy URI  

The secure address for each repository is used to access and clone. You must know the secure address before you create a local copy.  

In your **Web browser**, perform the following tasks.  
1.  Visit **Code Browser** page for each repository 
    1.  Copy the uri for the **Clone uri** text box  
    2.  Save the uri for later use  

After completing this task for each package, you have the following uri values for each of the empty repositories on GitFarm.  

|  | GitFarm Location | Clone uri |  
|:--- |:--- |:--- |  
| MWS Build | [code.amazon.com/packages/MWSDocumentationBuild](https://code.amazon.com/packages/MWSDocumentationBuild) | `ssh://git.amazon.com/pkg/MWSDocumentationBuild` |  
| SP API Build | [code.amazon.com/packages/SPDSDocumentationBuild](https://code.amazon.com/packages/SPDSDocumentationBuild) | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` |  
| English | [code.amazon.com/packages/SPDSDocumentation-en_US]([https://code.amazon.com/packages/SPDSDocumentation-en_US) | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` |  
| Japanese | [code.amazon.com/packages/SPDSDocumentation-ja_JP](https://code.amazon.com/packages/SPDSDocumentation-ja_JP) | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` |  
| Portuguese | [code.amazon.com/packages/SPDSDocumentation-pt_BR](https://code.amazon.com/packages/SPDSDocumentation-pt_BR) | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` |  
| Turkish | [code.amazon.com/packages/SPDSDocumentation-tr_TR](https://code.amazon.com/packages/SPDSDocumentation-tr_TR) | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` |  
| Chinese | [code.amazon.com/packages/SPDSDocumentation-zh_CN](https://code.amazon.com/packages/SPDSDocumentation-zh_CN) | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` |  


### Use Git to Clone Repositories  

You use the secure address to create a local copy using the `git clone` command via the command-line.  
You may use the **GitHub Desktop** application in place of the command-line.  

*   If you use a command-line tool or shell, use the following steps to create a local clone for each repository.  
    1.  Create a directory for each repository.  
        *   If you use the `bash` shell  on Posix or Windows
                        
            ```bash
            mkdir [local_path]
            ```  
            
        *   If you use the **Command Prompt** on Windows  
            
            ```cmd
            ​md [local_path]
            ```  
            
    2.  Use the `git clone` command to attach each GitFarm repository to each local directory.  
        
        ```shell
        git clone [clone_uri] [local_path]
        ```  

    3.  Navigate to each directory.  
        
        ```shell
        cd [local_path]
        ```  
        
    4.  Checkout the `mainline` branch for each repository.  
        
        ```shell
        git checkout mainline​
        ```  

*   If you use **GitHub Desktop**, use the following steps to create a local clone for each repository.  
    1.  Open the **Clone a repository** pop-up window using one of the following options.  
        *   Select **File** > **Clone Repository...**  
        *   Press `Ctrl`+`Shift`+`O`  
        *   Click on **Current repository** button, click on **Add** button, and select **Clone Repository...**  
    2.  On the **Clone a repository** pop-up window.  
        1.  Select the **URL** tab.  
            *   In the **Repository URl or GitHub username and repository** text box, enter the **Clone uri** value.
            *   In the **Local path** text box, enter the local path.  
        2.  Click on **Clone** button.  

After completing this task for each of the repositories, you have local directories cloned for each of the GitFarm repositories.  

*   On Posix  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |  
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | /spds/git/SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | /spds/git/SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | /spds/git/SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | /spds/git/SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | /spds/git/SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | /spds/git/SPDSDocumentation-zh_CN |  
    
*   On Windows using `bash`  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |   
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | /c/spds/git/SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | /c/spds/git/SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | /c/spds/git/SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | /c/spds/git/SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | /c/spds/git/SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | /c/spds/git/SPDSDocumentation-zh_CN |  
    
*   On Windows  
    
    |  | Clone uri | local path |  
    |:--- |:--- |:--- |   
    | SPDS Build | `ssh://git.amazon.com/pkg/SPDSDocumentationBuild` | C:\spds\git\SPDSDocumentationBuild |  
    | English | `ssh://git.amazon.com/pkg/SPDSDocumentation-en_US` | C:\spds\git\SPDSDocumentation-en_US |  
    | Japanese | `ssh://git.amazon.com/pkg/SPDSDocumentation-ja_JP` | C:\spds\git\SPDSDocumentation-ja_JP |  
    | Portuguese | `ssh://git.amazon.com/pkg/SPDSDocumentation-pt_BR` | C:\spds\git\SPDSDocumentation-pt_BR |  
    | Turkish | `ssh://git.amazon.com/pkg/SPDSDocumentation-tr_TR` | C:\spds\git\SPDSDocumentation-tr_TR |  
    | Chinese | `ssh://git.amazon.com/pkg/SPDSDocumentation-zh_CN` | C:\spds\git\SPDSDocumentation-zh_CN |  


## Add Initial Content to Build Repository  

The Amazon AP API directory \(`SPDSDocumentationBuild`\) and Amazon MWS \(`build_tools`\) directory are used to build the SP API output from DITA xml topic files.  
The specialized formatting needed for html is not currently available in the `SPDSDocumentationBuild` directory.  
The GitHub-flavored markdown is created using the local `SPDSDocumentationBuild` directory.  


### Download Latest DITA-OT  

*   In your **Web browser**, perform the following tasks.  
    1.  Visit [DITA-OT 3.3](https://www.dita-ot.org/download)  
    2.  Download the zip file to your `downloads` directory  
*   In your file browser  
    1.  Extract the contents of the zip file  
        *   Posix : `/downloads/dita-ot-3.3/dita-ot-3.3`  
        *   Windows \(`bash`\) : `/c/downloads/dita-ot-3.3/dita-ot-3.3`  
        *   Windows : `C:\downloads\dita-ot-3.3\dita-ot-3.3`  


### Copy DITA-OT into Build Repository  

*   If you use a command-line tool or shell, use the following steps to create a local clone for each repository.  
    1.  Create a directory for the repository.  
        *   If you use the `bash` shell  on Posix or Windows
                        
            ```bash
            cp -R [download_location] [dita_location]
            ```  
            
        *   If you use the **Command Prompt** on Windows  
            
            ```cmd
            xcopy /E /I [download_location]/*.* [dita_location]
            ```  

After completing this task, you have a local directory cloned from the private repository on GitHub.  

*   On Posix  
    
    |  | Download location | DITA location |  
    |:--- |:--- |:--- |  
    | SP API Build | `/downloads/dita-ot-3.3/dita-ot-3.3` | /spds/git/SPDSDocumentationBuild/dita-ot-3.3 |  
    
*   On Windows using `bash`  
    
    |  | Download location | DITA location |  
    |:--- |:--- |:--- |  
    | SP API Build | `/c/downloads/dita-ot-3.3/dita-ot-3.3` | /c/spds/git/SPDSDocumentationBuild/dita-ot-3.3 |  
    
*   On Windows  
    
    |  | Download location | DITA location |  
    |:--- |:--- |:--- |  
    | SP API Build | `C:\downloads\dita-ot-3.3\dita-ot-3.3/` | C:\spds\git\SPDSDocumentationBuild\dita-ot-3.3 |  


## Add Initial Content to Documentation Repositories  

Each language repository contains language-specific content and country-specific formatting.  
All languages are synchronized with English and translated.  


### Migrate GitHub Markdown into English Repository  

Copy the contents of the Amazon SP API Alpha developer guide into the English repository.  
The Amazon SP API Alpha developer guide is a single markdown file that must be converted to multiple DITA topic xml files.  


#### Clone the Private Repository into a Local Directory

Create a local copy of the Amazon Marketplace API SDK private GitHub repository \(`amazon-marketplace-api-sdk`\).  

*   If you use a command-line tool or shell, use the following steps to create a local clone for each repository.  
    1.  Create a directory for the repository.  
        *   If you use the `bash` shell  on Posix or Windows
                        
            ```bash
            mkdir [local_path]
            ```  
            
        *   If you use the **Command Prompt** on Windows  
            
            ```cmd
            ​md [local_path]
            ```  
            
    2.  Use the `git clone` command to attach the GitHub repository to the local directory.  
        
        ```shell
        git clone [github_uri] [local_path]
        ```  

    3.  Navigate to the directory.  
        
        ```shell
        cd [local_path]
        ```  
        
    4.  Checkout the `master` branch for the repository.  
        
        ```shell
        git checkout master
        ```  

*   If you use **GitHub Desktop**, use the following steps to create a local clone for each repository.  
    1.  Open the **Clone a repository** pop-up window using one of the following options.  
        *   Select **File** > **Clone Repository...**  
        *   Press `Ctrl`+`Shift`+`O`  
        *   Click on **Current repository** button, click on **Add** button, and select **Clone Repository...**  
    2.  On the **Clone a repository** pop-up window.  
        1.  Select the GitHub.com tab.  
            1.  In the Filter text box, enter the following text.  
                *   `amazon-marketplace-api-sdk`  
            2.  Under *amzn*, select `amzn/amazon-marketplace-api-sdk`.  
            * *  In the Local path test box, enter the following location.  
                *   Posix \(`bash`\) : `/spds/git/amazon-marketplace-api-sdk`  
                *   Windows \(`bash`\) : `/c/spds/git/amazon-marketplace-api-sdk`  
                *   Windows : `C:\spds\git\amazon-marketplace-api-sdk`  
        2.  Click on **Clone** button.  

After completing this task, you have a local directory cloned from the private GitHub repository.  

*   On Posix  
    
    |  | GitHub uri | local path |  
    |:--- |:--- |:--- |  
    | Alpha | `https://github.com/amzn/amazon-marketplace-api-sdk.git` | /spds/git/amazon-marketplace-api-sdk |  
    
*   On Windows using `bash`  
    
    |  | GitHub uri | local path |  
    |:--- |:--- |:--- |  
    | Alpha | `https://github.com/amzn/amazon-marketplace-api-sdk.git` | /c/spds/git/amazon-marketplace-api-sdk |  
    
*   On Windows  
    
    |  | GitHub uri | local path |  
    |:--- |:--- |:--- |  
    | Alpha | `https://github.com/amzn/amazon-marketplace-api-sdk.git` | C:\spds\git\amazon-marketplace-api-sdk |  


#### Copy Markdown into Local English Directory  

Copy the Developer Guide markdown file into a sub-directory in the Amazon SP API English directory.  

1.  Create a directory for the repository.  
    *   If you use the `bash` shell  on Posix or Windows
                    
        ```bash
        mkdir [sp_api_directory]
        ```  
        
    *   If you use the **Command Prompt** on Windows  
        
        ```cmd
        ​md [sp_api_directory]
        ```  

2.  Copy the markdown file into the new directory.  
    *   If you use the `bash` shell  on Posix or Windows
                    
        ```bash
        cp -R [source_location] [sp_api_directory]
        ```  
        
    *   If you use the **Command Prompt** on Windows  
        
        ```cmd
        xcopy /E /I [source_location] [sp_api_directory]
        ```  
        
After completing this task, you have a copy of the Developer Guide markdown file in the `sourceForImport` directory in the Amazon SP API English repository.  

*   On Posix  
    
    |  | Markdown source location  | SPA API Directory |  
    |:--- |:--- |:--- |  
    | Dev Guide | `/spds/git/amazon-marketplace-api-sdk/developer-guide/spds-marketplace_api-dev_guide-alpha.md` | /spds/git/SPDSDocumentation-en_US/sourceForImport |  
    
*   On Windows using `bash`  
    
    |  | GitHub uri | local path |  
    |:--- |:--- |:--- |  
    | Dev Guide | `/c/spds/git/amazon-marketplace-api-sdk/developer-guide/spds-marketplace_api-dev_guide-alpha.md` | /c/spds/git/SPDSDocumentation-en_US/sourceForImport |  
    
*   On Windows  
    
    |  | GitHub uri | local path |  
    |:--- |:--- |:--- |  
    | Dev Guide | `C:\spds\git\amazon-marketplace-api-sdk\developer-guide\spds-marketplace_api-dev_guide-alpha.md` | C:\spds\git\SPDSDocumentation-en_US\sourceForImport |  


#### Create a Ditamap File for the Markdown  

Use the built-in markdown-to-DITA conversion option in OxygenXML.  

*   In **OxygenXML**  
    1. Create a new ditamap file named `markdown_to_dita.ditamap` in the `sourceForImport` directory in the Amazon SP API English repository.  
*   In a test editor  
    1.   Open the ditamap file as text and paste the following text.  
         
         ```xml
        <!DOCTYPE map PUBLIC "-//OASIS//DTD DITA Map//EN" "map.dtd">
        <map>
            <topicref href="./spds-marketplace_api-dev_guide-alpha.md" format="markdown"/>
        </map>
        ```  
        
    3.  Save the ditamap file.  
*   In Oxygen, in the Dita Maps Manager  
    1.  Open `markdown_to_dita.ditamap`.  
    2.  Click on `spds-marketplace_api-dev_guide-alpha.md`.  
    3.  Click on `Document` \> `Source` \> `Export as DITA topic`.  
    4.  Save the new DITA topic to in the `developer_guide` directory in the Amazon SP API English repository.  

After completing this task, you have a DITA xml topic file based upon the Developer Guide markdown file in the `developer_guide` directory.  


#### Separate DITA Content into Individual Topics  

The converted DITA is a single file that you should separate into individual topics.  
Separating the topics includes updating the ditamap to reflect the existing hierarchy found in the single file.  

*   In **OxygenXML**  
    1.  Create a ditamap file named `amazon_sp_api_dev_guide_en_us.ditamap` in the `developer_guide` directory in the Amazon SP API English repository.  
*   In a test editor  
    1.  Open the ditamap file as text and paste the following text.  
         
        ```xml
        <!DOCTYPE map PUBLIC "-//OASIS//DTD DITA Map//EN" "map.dtd">
        <map id="DG_dita_map" title="Amazon Marketplace API Developer Guide: Alpha">
            <topicmeta>
                <author type="creator">[creator_name]</author>
                <copyright>
                    <copyryear year="2019"/>
                    <copyrholder>Amazon.com, Inc. or its affiliates</copyrholder>
                </copyright>
                <critdates>
                    <created date="[created_date]"/>
                    <revised modified="[current_date]"/>
                </critdates>
                <audience type="developer"/>
                <prodinfo>
                    <prodname>Amazon Marketplace API</prodname>
                    <vrmlist>
                        <vrm version="Alpha" release="2"/>
                    </vrmlist>
                    <component>Amazon Marketplace API Developer Guide</component>
                </prodinfo>
            </topicmeta>
            <topicref format="dita" href="./amazon_sp_api-dev_guide.dita" navtitle="Document History" type="topic" scope="local"/>
        </map>
        ```  
        
    3.  Save the ditamap file.  
*   In **OxygenXML**, in the** Dita Maps Manager**  
    1.  Open `amazon_sp_api_dev_guide_en_us.ditamap`.  
    2.  Manually separate each topic in the dita file into individual DITA files.  
    3.  Attach individual dita files to ditamap.  

After completing this task, you have multiple DITA topic files in the `developer_guide` directory.  


#### Clean DITA Topics  

Clean up the DITA xml topic files by adding the correct formatting, style, and metadata.  

*   In **OxygenXML**  
    1.  Replace internal links with dita xrefs.  
        1.  Match links to dita xml topic file names.  
        2.  Change format to dita.  
    2.  Move code samples into individual files.  
        1.  Create files in examples directory for each code example.  
        2.  Attached code example to topic.  
    3.  Clean up notes.  
        *   Replace notes with DITA notes.  
        *   Replace important with DITA notes with type set to important.  
    4.  Clean up lists.  
        *   Bulleted and unordered lists.  
        *   Numbered and ordered lists.  

After completing this task, you have content that accurately reflects the content and formatting of the source markdown file.  


## Replicate Content  

Each language may have ongoing replication due to changes and the selected translation process.  


### Copy English Repository to Other Languages  

Copy the DITA xml topic files, DITA Map, and directory structure from the English repository into each of the other language repositories.  
*   Japanese : `ja_JP`  
*   Portugeuse : `pt_BR`  
*   Turkish : `tr_TR`  
*   Chinese : `zh_CN`  

The initial content for each language is copied from the English repository.  


### Translate Other Language Repositories  

**REVIEW NOTE**: Work with Simona to determine effort and timeline requirements.  

\[Under Construction\]


## Save Changes to Repository  

1.  Save the changes to the files and directories.  

2.  Add files to track in a commit.  
    In the directory associated with the repository, add a file.  

    ```shell
    git add [path/to/file_name.ext]
    ```  

2.  Create a commit.  
    In the directory associated with the repository, create a commit associated with the tracked files.  

    ```shell
    git -am commit "[insert_commit_message]"
    ```  

3.  Push all commits to the repository.   
    In the directory associated with the repository, push the commits.  

    ```shell
    git push
    ```  

After completing this task, your local changes are available in the associated GitFarm repository.  

