# SPDS Docs scripts  

**SPDS**
| variable | code |  
|:--- |:--- |  
|  |  |  


Create file at `~/.aws/credentials` \(or in `%UserProfile%\.aws/credentials`\)

```
[default]
aws_access_key_id=AKIA3ITE6SW46SZ5D65F
aws_secret_access_key=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

[testing]
aws_access_key_id=foo
aws_secret_access_key=bar
```  

Create file at `~/.aws/config` \(or in `%UserProfile%\.aws\config`\)

```
[default]
aws_access_key_id=AKIA3ITE6SW46SZ5D65F
aws_secret_access_key=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
# Optional, to define default region for this profile.
region=us-west-2
output=json

[testing]
aws_access_key_id=foo
aws_secret_access_key=bar
# Optional, to define default region for this profile.
region=us-west-2
output=json
```  

Verify AWS credentials are up-to-date.  

```
cs-describe-domain
```  


**MWS - Windows cmd \(old\)**
| variable | Windows |  
|:--- |:--- |:--- |  
|  |  |  
| MWS directory                                       | `setx MWS_HOME "C:\mws"` |  
|  |  |  
| MWS build tools directory                           | `setx BUILD_TOOLS_HOME "%MWS_HOME%\git\build_tools"` |  
| MWS CloudSearch v2011-02-01 directory               | `setx CS_HOME "%BUILD_TOOLS_HOME%\CloudSearch\v2011-02-01"` |  
| MWS DITA-OT v1.8.5 directory                        | `setx DITA_DIR "%BUILD_TOOLS_HOME%\DITA-OT1.8.5\"` |  
| MWS DITA-OT ANT directory                           | `setx ANT_HOME "%DITA_DIR%\tools\ant"` |  
| MWS build tools html directory                      | `setx BUILD_HTML_HOME "%BUILD_TOOLS_HOME%\build_html"` |  
| MWS documentation en_US directory                   | `setx MWSUS "%MWS_HOME%/git/en_US"` |  
| MWS documentation ja_JP directory                   | `setx MWSJP "%MWS_HOME%/git/ja_JP"` |  
| MWS documentation zh_CN directory                   | `setx MWSCN "%MWS_HOME%/git/zh_CN"` |  
|  |  |  
| SPDS directory                                      | `setx SP_HOME "C:\spds"` |  
| SPDS build tools directory                          | `setx SP_BUILD_TOOLS_HOME "%SPDS_HOME%\git\SPDSDocumentationBuild"` |  
| SPDS build tools html directory                     | `setx SP_BUILD_HTML_HOME "%SPDS_BUILD_TOOLS_HOME%\build_html"` |  
| SPDS CloudSearch v2011-02-01 directory              | `setx SP_CS_HOME "%SPDS_BUILD_TOOLS_HOME%\CloudSearch\v2011-02-01"` |  
| SPDS DITA-OT v1.8.5 directory                       | `setx SP_DITA_DIR "%SPDS_BUILD_TOOLS_HOME%\dita-ot3.3\"` |  
| SPDS documentation en_US directory                  | `setx SPUS "%SPDS_HOME%/git/en_US"` |  
| SPDS documentation ja_JP directory                  | `setx SPJP "%SPDS_HOME%/git/ja_JP"` |  
| SPDS documentation pt_BR directory                  | `setx SPBR "%SPDS_HOME%/git/pt_BR"` |  
| SPDS documentation tr_TR directory                  | `setx SPTR "%SPDS_HOME%/git/tr_TR"` |  
| SPDS documentation zh_CN directory                  | `setx SPCN "%SPDS_HOME%/git/zh_CN"` |  
|  |  |  
| AWS access key                                      | `setx AWS_ACCESS_KEY_ID "[access_key]"` |  
| AWS Config file                                     | `setx AWS_CONFIG_FILE "%UserProfile%\.aws/config"` |  
| AWS Credentials file                                | `setx AWS_SHARED_CREDENTIAL_FILE "%UserProfile%\.aws/credentials"` |  
| AWS secret key                                      | `setx AWS_SECRET_ACCESS_KEY "[secret_key]"` |  
|  |  |  
| MWS PuTTY CLI                                       | `setx GIT_SSH "%ProgramFiles%\PuTTY\plink.exe"` |  
| Amazon Corretto JDK v1.8.0_201 directory            | REM `setx JAVA_HOME "%ProgramFiles%\Amazon Corretto\jdk1.8.0_201"` |  
| Oracle JDK v1.8.0_191 directory                     | `setx JAVA_HOME "%ProgramFiles%\Java\jdk1.8.0_191"` |  
| Python v2.7 directory                               | `setx PYTHONHOME "C:\Python27"` |  
| Python v3.7 directory                               | REM `setx PYTHONHOME "C:\Python37"` |  
| ANT options  part 1                                 | `setx ANT_OPTS "-Xmx512m %ANT_OPTS%"` |  
| ANT options, part 2                                 | `setx ANT_OPTS "%ANT_OPTS% -Djavax.xml.transform.TransformerFactory=net.sf.saxon.TransformerFactoryImpl"` |  
| Path addition for Python directory                  | `setx PATH "%PYTHONHOME%;%PATH%"` |  
| Path addition for MWS CloudSearch directory         | `setx PATH "%CS_HOME%\bin;%PATH%"` |  
| Path addition for MWS build tools directory         | `setx PATH "%BUILD_HTML_HOME%\bin;%PATH%"` |  
| Path addition for JDK directory                     | `setx PATH "%JAVA_HOME%\bin;%PATH%"` |  
| Path addition for MWS DITA-OT ANT bin directory     | `setx PATH "%DITA_DIR%\tools\ant\bin;%PATH%"` |  
| Classpath addition for icu4j .jar file              | `setx CLASSPATH "%DITA_DIR%\lib\icu4j.jar;"` |  
| Classpath addition for commons codec v1.4 .jar file | `setx CLASSPATH "%DITA_DIR%\lib\commons-codec-1.4.jar;"` |  
| Classpath addition for resolver .jar file           | `setx CLASSPATH "%DITA_DIR%\lib\resolver.jar;"` |  
| Classpath addition for dost .jar file               | `setx CLASSPATH "%DITA_DIR%\lib\dost.jar;"` |  
| Classpath addition for DITA-OT lib directory        | `setx CLASSPATH "%DITA_DIR%\lib;"` |  
| Classpath addition for xml-apis .jar file           | `setx CLASSPATH "%DITA_DIR%\lib\xml-apis.jar;%CLASSPATH%"` |  
| Classpath addition for xercesImpl  .jar file        | `setx CLASSPATH "%DITA_DIR%\lib\xercesImpl.jar;%CLASSPATH%"` |  
| Classpath addition for saxon9-dom .jar file         | `setx CLASSPATH "%DITA_DIR%\lib\saxon\saxon9-dom.jar;%CLASSPATH%"` |  
| Classpath addition for saxon9 .jar file             | `setx CLASSPATH "%DITA_DIR%\lib\saxon\saxon9.jar;%CLASSPATH%"` | 

**MWS - Windows Bash \(old\)**
| variable | Posix |  
|:--- |:--- |:--- |  
|  |  |  
| MWS directory                                       | `export MWS_HOME=/c/mws` |  
|  |  |  
| MWS build tools html directory                      | `export BUILD_HTML_HOME=$BUILD_TOOLS_HOME/build_html` |  
| MWS CloudSearch v2011-02-01 directory               | `export CS_HOME=$BUILD_TOOLS_HOME/CloudSearch/v2011-02-01` |  
| MWS DITA-OT v1.8.5 directory                        | `export DITA_DIR=$BUILD_TOOLS_HOME/DITA-OT1.8.5/` |  
| MWS DITA-OT ANT directory                           | `export ANT_HOME=$DITA_DIR/tools/ant` |  
| MWS documentation en_US directory                   | `export MWSUS=$MWS_HOME/git/en_US` |  
| MWS documentation ja_JP directory                   | `export MWSJP=$MWS_HOME/git/ja_JP` |  
| MWS documentation zh_CN directory                   | `export MWSCN=$MWS_HOME/git/zh_CN` |  
|  |  |  
| AWS access key                                      | `export AWS_ACCESS_KEY_ID=[access_key]` |  
| AWS Config file                                     | `export AWS_CONFIG_FILE=~/.aws/config` |  
| AWS Credentials file                                | `export AWS_SHARED_CREDENTIAL_FILE=~/.aws/credentials` |  
| AWS secret key                                      | `export AWS_SECRET_ACCESS_KEY=[secret_key]` |  
|  |  |  
| MWS PuTTY CLI                                       | `export GIT_SSH=$ProgramFiles/PuTTY/plink.exe` |  
| Amazon Corretto JDK v1.8.0_201 directory            | REM `export JAVA_HOME=$ProgramFiles/Amazon Corretto/jdk1.8.0_201` |  
| Oracle JDK v1.8.0_191 directory                     | `export JAVA_HOME=$ProgramFiles/Java/jdk1.8.0_191` |  
| Python v2.7 directory                               | `export PYTHONHOME=/c/Python27` |  
| Python v3.7 directory                               | REM `export PYTHONHOME=/c/Python37` |  
| ANT options  part 1                                 | `export ANT_OPTS=-Xmx512m $ANT_OPTS` |  
| ANT options, part 2                                 | `export ANT_OPTS=$ANT_OPTS -Djavax.xml.transform.TransformerFactory=net.sf.saxon.TransformerFactoryImpl` |  
| Path addition for Python directory                  | `export PATH=$PYTHONHOME;$PATH` |  
| Path addition for MWS CloudSearch directory         | `export PATH=$CS_HOME/bin;$PATH` |  
| Path addition for MWS build tools directory         | `export PATH=$BUILD_HTML_HOME/bin;$PATH` |  
| Path addition for JDK directory                     | `export PATH=$JAVA_HOME/bin;$PATH` |  
| Path addition for MWS DITA-OT ANT bin directory     | `export PATH=$DITA_DIR/tools/ant/bin;$PATH` |  
| Classpath addition for icu4j .jar file              | `export CLASSPATH=$DITA_DIR/lib/icu4j.jar;` |  
| Classpath addition for commons codec v1.4 .jar file | `export CLASSPATH=$DITA_DIR/lib/commons-codec-1.4.jar;` |  
| Classpath addition for resolver .jar file           | `export CLASSPATH=$DITA_DIR/lib/resolver.jar;` |  
| Classpath addition for dost .jar file               | `export CLASSPATH=$DITA_DIR/lib/dost.jar;` |  
| Classpath addition for DITA-OT lib directory        | `export CLASSPATH=$DITA_DIR/lib;` |  
| Classpath addition for xml-apis .jar file           | `export CLASSPATH=$DITA_DIR/lib/xml-apis.jar;$CLASSPATH` |  
| Classpath addition for xercesImpl  .jar file        | `export CLASSPATH=$DITA_DIR/lib/xercesImpl.jar;$CLASSPATH` |  
| Classpath addition for saxon9-dom .jar file         | `export CLASSPATH=$DITA_DIR/lib/saxon/saxon9-dom.jar;$CLASSPATH` |  
| Classpath addition for saxon9 .jar file             | `export CLASSPATH=$DITA_DIR/lib/saxon/saxon9.jar;$CLASSPATH` | 

## Create CloudSearch file 

Set epoch.time
```
property = project.setProperty("epoch.time", Math.floor((new Date()).getTime()/1000));
```  

create sdf file  
```
cmd /c ${cs.bin.dir}\cs-generate-sdf.cmd ${cs-generate-sdf-args}
```  

expanded command directory  
```
cmd /c ${env.CS_HOME}\bin\cs-generate-sdf.cmd ${cs-generate-sdf-args}
```  

expand arguments  
```
cmd /c C:\spds\git\SPDSDocumentationBuild\CloudSearch\v2011-02-01\bin\cs-generate-sdf.cmd -s ${sdf.out.dir}\**\*.html -o ${sdf.out.dir} -dv ${epoch.time}
```  

## Renew AWS Credentials  

If you do not have the proper AWS credentials, you will not be able to deploy documentation using the deploy command.  
You will need to access the Odin credentials for `mws-tech-writers` and set the `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` environment variables.  


### Getting AWS credentials using a Linux computer  

This requires a Linux computer with RHEL5 and `odin-get`.  

1.	On your Linux machine with odin-get installed, run the following command.  
    *   `odin-get com.amazon.access.MWS-AWS-mws-tech-writers-1`  
    
    > **NOTE**:  If you don’t have a Linux machine with `odin-get` installed, see the following.
    > 
    > > **Getting AWS credentials using a Windows computer**  
    > > 
    > > Before you begin, make sure you have PuTTY installed.  See Configuring PuTTY.  
    > > To get AWS credentials:  
    > > 1.  Launch PuTTY.  
    > > 2.  In the Host Name \(or IP address\) box, enter  `beta-tools-na-2a-9d4be40a.us-west-2.amazon.com`  
    > >     
    > >     > **NOTE**: AWS host names occasionally rotate.  
    > >     > If you are unable to connect to the host, get the new host name.  
    > >     > Go to https://apollo.amazon.com/environments/MarketplaceWebServiceAuthorizationTools/NA/stages/Beta. 
    > >     > *   Under *Tag*, expand *2a* to get the new host name.  
    > > 
    > > 3.  Ensure that Port=`22` and Connection type=`SSH`.  
    > >     Click Open.  
    > >     The PuTTY CLI opens.  
    > > 4.  Run this command.  
    > >     
    > >     ```shell
    > >     /apollo/env/envImprovement/bin/odin-get com.amazon.access.MWS-AWS-mws-tech-writers-1
    > >     ```  
    > > 
    > >     Your AWS credentials appear.  
    
2.	Set `AWS_ACCESS_KEY_ID` on your Windows machine to match the first line returned by **odin-get**.  
    1.  At Windows command line.
        
        ```shell
        SETX AWS_ACCESS_KEY_ID num
        ```  
        
    2.  Or, Control Panel->System->Advanced System Settings->Environment Variables  
3.	Set `AWS_SECRET_ACCESS_KEY` on your Windows machine to match the second, much longer line returned by **odin-get**.  
    1.  At Windows command line.
        
        ```shell
        SETX AWS_SECRET_ACCESS_KEY num
        ```    
        

## Push to S3 in Production  

> **AWS CLI**
> 
> ```shell
> aws s3 sync "%MWS_HOME%\_out\master" "s3://docs.developer.amazonservices.com" --delete --exclude "%MWS_HOME%\_out\master\docs.html" --include "%MWS_HOME%\_out\master\css\*" --region us-east-1 --source-region us-east-1
> ```  


## Update index on S3 in Production  

> **CMD**
> 
> ```shell
> CALL c:\mws\git\build_tools\CloudSearch\v2011-02-01\bin\cs-post-sdf.cmd --source c:\mws\_out_sdf\master\1.sdf --domain-name mws-htmldocs-prod --access-key %AWS_ACCESS_KEY_ID% --secret-key %AWS_SECRET_ACCESS_KEY%
> ```  


## Invalidate CloudFront Distribution

> **AWS CLI**
> 
> ```shell
> aws cloudfront create-invalidation --distribution-id E1LZRMHNBQ2JCH --paths /*
> ```  

or   

> 1.  Visit the [MWS-AWS AWS Account](https://access.amazon.com/aws/accounts/show/MWS-AWS) page.  
>     1.  Click on the **Console Access** button.  
> 2.  On the *AWS Management Console* page, under *Networking \& Content Delivery* section or the *Recently visited services* section.  
>     1.  Click on the  **CloudFront** link.  
> 3.  On the CloudFront Distributions page.  
>     1.  Click on the \[distribution ID\].  
> 4.  On the CloudFront Distributions > \[distribution ID\] page.  
>     1.  Select the **Invalidation** tab.  
>         1.  Click on the **Create Invalidation** button.  
> 5.  On the *Create Invalidation* pop-up window.  
>     1.  In the *Object Paths* textbox, enter the following.  
>         
>         ```
>         /*
>         ```  
>         
>     2.  Click on the **Invalidate** button.  
> 6.  Verify that the live pages match the expected content.  
>     *   [docs.developer.amazonservices.com/en_US/dev_guide](http://docs.developer.amazonservices.com/en_US/dev_guide)  
>     *   [docs.developer.amazonservices.com/ja_JP/dev_guide](http://docs.developer.amazonservices.com/ja_JP/dev_guide)  
>     *   [docs.developer.amazonservices.com/zh_CN/dev_guide](http://docs.developer.amazonservices.com/zh_CN/dev_guide)  
> 


## Push to S3 in Devo/Beta  

> **AWS CLI**
> 
> ```shell
> aws s3 sync "%MWS_HOME%\_out\local" "s3://devo.docs.developer.amazonservices.com" --delete --exclude "%MWS_HOME%\_out\local\docs.html" --include "%MWS_HOME%\_out\local\css\*" --region us-east-1 --source-region us-east-1
> ```  


## Update index on S3 in Devo/beta  

> **cmd**
> 
> ```shell
> CALL C:\mws\git\build_tools\CloudSearch\v2011-02-01\bin\cs-post-sdf.cmd --source c:\mws\_out_sdf\master\1.sdf --domain-name mws-htmldocs-beta --access-key %AWS_ACCESS_KEY_ID% --secret-key %AWS_SECRET_ACCESS_KEY%
> ```  

> Verify that the live pages match the expected content.  
> *   [devo.docs.developer.amazonservices.com/en_US/dev_guide/index.html](https://s3.amazonaws.com/devo.docs.developer.amazonservices.com/en_US/dev_guide/index.html)  
> *   [devo.docs.developer.amazonservices.com/ja_JP/dev_guide/index.html](https://s3.amazonaws.com/devo.docs.developer.amazonservices.com/ja_JP/dev_guide/index.html)  
> *   [devo.docs.developer.amazonservices.com/zh_CN/dev_guide/index.html](https://s3.amazonaws.com/devo.docs.developer.amazonservices.com/zh_CN/dev_guide/index.html)  
