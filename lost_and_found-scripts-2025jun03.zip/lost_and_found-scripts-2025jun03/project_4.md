# Project 4  

Suggested Project:  I would like to create an updated review process between CM team and stakeholders.  

I need to work with my peers to identify if this meets the needs of our reviewers and requesters ( or any stakeholder).  

Purpose: 
*   To provide a method for reviewing content that does not modify the code samples.  

Problem: 
*   The existing review process involves MS Word, which adds smart formatting and hides formatting information.  

Solution: 
*   Replace MS Word and the use of .docx files for content reviews.  
*   Use of markdown or similar light-weight markup language only.  

Conditions: 
*   Reviewers should not be required to purchase any piece of software.  
*   The content can be reviewed in part (updates only) or as a whole.  
*   Files being reviewed should be searchable (flat) files.  

Ideal Conditions: 
*   Reviewers can review content via web browser.  
*   Compatible with code.amazon.com, WorkDocs, share.amazon.com  
*   Review process can be automated (in part or as a whole).  

