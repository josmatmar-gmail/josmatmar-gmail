<a 
    href="mailto:Eryka.Adams@Clickdimensions.com
                 ?bcc=julie.patrick@clickdimensions.com
                 &subject=RSVP%20for%20New%20Year's%20Eve%20Party%20
                 &body=Hi%20Bob,%0d
                       %0d
                       I%20would%20like%20to%20RSVP%20to%20your%20party%20invitation.%20Here%20are%20my%20details:%0d
                       %0d
                       Name:%20Eryka%20Adams%0d
                       Number%20of%20Guest:%0d
         "
    rel="EMAIL">here</a>

