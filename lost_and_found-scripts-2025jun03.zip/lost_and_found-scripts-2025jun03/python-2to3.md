2to3 for python3

/path/to/python3 -d /path/to/python3/tools/scripts/2to3.py /path/to/python2/file.py

/c/Python37/python -d /c/python37/tools/scripts/2to3.py createIndexhtmlfiles.py

