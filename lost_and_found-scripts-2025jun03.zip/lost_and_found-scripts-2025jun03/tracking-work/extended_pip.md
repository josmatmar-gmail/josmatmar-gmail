| Priority | Description | Due | update | 
|:--- |:--- |:--- |:--- |  
| 7 | Author and publish to the SPDS Evergreen doc site a comprehensive how-to guide for API authors to generate SPDS API Technical references via self-service. Review the final deliverable (and incorporate feedback) with appropriate technical and business stakeholders (including manager) by 5/17. | 5/17/2019 | (1-2 only 1st reading) feedback via wiki - swa, feedback - ldx, dalton, andrew, rick, evan, daniel, katrina (fyi), dan (fyi)  review meeting (I think we are done) scope from close to customer... |  
| 8 | Author and publish to wiki a comprehensive overview, technical design summary, and process guide to author, publish, and change SPDS API documentation on the public Developer Doc site/portal. Review final deliverable with appropriate technical and business stakeholders (including manager) by 5/31. | 5/31/2019 | Context Feedback ain summary rick,  |  
| 9 | Contribute to ongoing Technical Writing team operations by owning the timely, high quality resolution of Data Redaction report SIMs and prioritized editorial reviews and intake requests as agreed upon in team planning throughout the duration of this PIP. | Ongoing til 5/31/2019 | numbers total, context, gating, rick work items and specialized call-outs |  
| 10 | Prepare a summarized delivery plan for the above initiatives and review status and blockers with your manager in weekly 1:1’s for the duration of this PIP. | Weekly starting 5/7/2019 til 5/31/2019 | Jumping on search |  
| 11 | Earn trust with partners and stakeholders through positive interactions and timely, high quality delivery throughout the duration of this PIP. Measured by solicited feedback.  | Ongoing til 5/31/2019 | List of names for feedback. mini forte |  


measure time in points  
program with time/points  


