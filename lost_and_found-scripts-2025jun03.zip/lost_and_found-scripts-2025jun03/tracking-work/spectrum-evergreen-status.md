| Smart Goal | By When | Measurement |  
|:--- |:--- |:--- |  
| **1. Deliver the Evergreen API authoring site.** | Site is live and can be viewed by all Amazonians by xx/xx/2019. | You were assigned this project in November 2018 and you repeatedly stated that it is finished but just needs to be launched. In December you committed to delivering the live site within PI-1, which ended on 2/22. You committed again during the week of 2/18-2/22 to launch it, but it remains undelivered.<br />  This site must be launched and available for review by 2 pm, Wednesday, 3/6 and must reflect the work of the an L5 Technical Writer who has used previous wiki content as a guide, added new, relevant content, and established a credible site that shows the level of work that you have frequently stated you have put into it. You must send an articulate, well-planned email to the greater Spectrum team at launch time, asking for specific comments and review feedback, which you will be prepared to evaluate and implement.<br />  The Evergreen site will be evaluated based upon its clarity of thinking and completeness as measured by external teams being able to launch SPDS APIs by using the site's structure and content.<br />  Specifically, the site will be measured on whether it raises the bar for an L5 TW on the following items:<ol> <li>Is the information clearly stated, well-presented, and does it demonstrate simplification and or improvement over the previous wiki and SharePoint content.</li>  <li>Does the content cover all required project components and align with the 2019 Spectrum  roadmap priorities, especially helping reduce the time it takes to deliver APIs.</li> </ol> |  
| **2. Train 3 people to be able to self-update content.** | Content can be edited by members of our team by xx/xx/2019 | You committed during the week of 2/18-2/22 to train others to add content, but it remains undelivered.<br />  You must have trained at least 3 peers so they can easily add/update content by 2 pm, Wednesday, 3/6.<br />  Specifically, the site will be measured on whether it raises the bar for an L5 TW on the following items:<ol> <li>Can SMEs easily add content to the site and have they been trained to execute content updates without requiring further training?</li> </ol> |  


## Deliverables for Evergreen  

*   Work with the Evergreen team to set-up Pipeline for code \(content\) publishing.  This is needed to make the content available outside of a CloudDesktop.  This might be the one that would delay the public launch, but I do expect a delay of more than 1 week.  
*   Verify that all of the links within the site work and point to a valid location.  Very manual, but I only need to do it once per page.  
*   Verify that all of the external links on the site work and point to a valid location.  Very manual, but I only need to do it once per page.  
*   Verify that the SPDS onboarding content that is owned by Spectrum and referenced in wiki, Quip, and SharePoint is present in the site.  Daniel provided a list via quip that I am leveraging to ensure the wiki content is tracked.  
*   Verify with Anjana (wiki Owner) that the entire onboarding workflow can be followed.  This effort can probably be done by me, but I will be paying close attention to responses and reactions from SPUDS team.  

## Deliverables for Training  

*   Update and deploy training content (in markdown).  
*   Determine training goals for each session.  
*   Set up training sessions for invitees based upon status.  
*   Determine the blocking issues for access to code.amazon \(gitFarm\) repo.  
*   Short-list of training candidate: @rickde; @kastod; @sharonll; @bonnerob; @ferradin; 
*   Ask Sonal if she would like members of her team to be included.  