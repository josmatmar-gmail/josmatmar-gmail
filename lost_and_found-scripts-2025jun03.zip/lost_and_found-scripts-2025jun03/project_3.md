# Project 3 \(and possibly Project 4\)

## TOPIC  

Deploy API content that incorporates feedback mechanisms.  


## GOALS  

> Verify if AWS is open to  
> *   connect prior to 
> *   for allowances \(Joe\)
> *   Maybe ask Brad  


*   Collaborate with peers and stakeholders to identify the issues with maintaining and building developer docs that that provide feedback mechanisms to the Spectrum team \(including PM tem, CM team, and DevSu\).  

*   Identify blockers for acceptance.  

*  Deliver project expectations and summary.  

*   Identify the requirements for analytics to be useful for Spectrum.  The requirements may include the following.  
    *   Thumbs up and thumbs down  
    *   Page-level tracking \(visitor focus, time, click-through\)  
    *   GitHub issues  
    *   Adobe Analytics  
    *   SIM \(internal only\)  
    *   CR using CRUX \(internal only\)  


## SUPPORTING CONTENT  

The current methods of content delivery.  

| content | process | destination | feedback |  
|:--- |:--- |:--- |:--- |  
| *MWS APIs* | *DITA-to-html* | *S3* | \* |  
| *MWS dev docs* | *DITA-to-html* | *S3* | \* |  
| SPDS APIs | Swagger-to-json-to-Swagger-to-html | Github | issues |  
| SPDS dev docs | markdown | GitHub | issues |  

\* Feedback currently provided by SC Forum comments, email communications, and developer meetings.  


## PREFERRED DOCUMENT FORMAT  

*  Word  
   *   PR FAQ for 2nd  
   *   Formal for 1st  


## CUSTOMERS  

*   SPDS and Hybrid \(MWS and SPDS\) API developers supported by Spectrum.  


## RESEARCH ACTIVITIES  

*   Meet with AWS teams to determine viability of deploying SPDS content with AWS partnership.  The content would include the existing content delivered from Swagger \(SPDS APIs\) and markdown \(developer guide\).  

*   Identify the requirements of the CM team \(Tech writing and translation\), PM team \(business requirements\), and DevSu team \(support and deployment\).  


## LONG-TERM VISION  

*   Simplify the method for obtaining feedback from API developers and client developers.  


## PHASING  

Similar tasks/deliverable using a set of tools or constraints.  

|  |  |  
|:--- |:--- |  
|  |  |  
| Investigation \(SPECTRUM\) |  draft due by `11:00` am Monday, `18-Mar-2019` |  
| Investigation \(AWS\) |  |  
| Prototype |  |  
| Test deploy |  |  


## ROLLOUT PLAN  

1.  Single operation \(proof of content\)  
2.  Single API  \(proof of formatting and linking internal\)  
3.  Single section  \(proof of linking across pages\)  
4.  3 Sections  \(proof of linking across sections\)  
5.  All Sections  \(final deployment\)  

## JUSTIFICATIONS  

| BENEFITS | TRADE-OFFS | RISKS | TECHNICAL DEBT |  
|:--- |:--- |:--- |:--- |  
| Leveraging existing robust and support technologies \(AWS\) | Control of direction and tools is shared with or controlled by AWS | Training curve may be too steep.  | New server instances.  Dev desktop requirements.  Training on non-Amazon technologies.  |  


## ACCEPTENCE CRITERIA  




## MEASURING DATA  

*   Number of methods to retrieve metrics \(time on page, click-through rate for links, per visitor metrics\)  
*   Number of pages successfully loaded with feedback mechanism in place.  


## IMPLEMENTING CHANGES  

*   Deliver content in chosen platform during testing phase  
*   Deliver content in chosen platform during deployment phase  
*   Deliver content in chosen platform for phase  

## Peer Collaboration  

Meet with at least 4 peers  
*   Analyze data  
*   Contribute to discussions  
*   Translate requirements into a quality business document  
*   Correctly plan to fulfill the needs of your customers  

\[  \]

---  

I would like to arrange meeting with the AWS team to determine the requirements for partnering with AWS for the creation of the SPDS API references and docs, as well as, the content for API developers and solution providers who Spectrum APIs to assist sellers.  
    
> [w.amazon.com/bin/view/AWSDocs](https://w.amazon.com/bin/view/AWSDocs)  
    
I would like to gather the requirements that the CM team has for delivering content.
*   Methods of capturing analytics \(usage tracking for docs\)  


*   Methods of delivering content   

*   Methods of review and road-tripping content  
    *   Sharing and incorporating reviews from legal, support, dev team, partners, et cetera.  

Should we consider WorkDocs SDK for our enterprise content management (ECM) solution?  

*   How do we know if we are delivering the right content?
    *   Short term:
        *   Determine if we can use Adobe Analytics: [w.amazon.com/bin/view/AWSDocs/create-a-dashboard/](https://w.amazon.com/bin/view/AWSDocs/create-a-dashboard/)
        *   Design an effective feedback loop that leverages the Developer Council and internal SPDS app developers.  EG Feedback on GitHub.  
        *   Improve the feedback loop between TW and SE teams. For example, TWs use Contact Us reason codes to understand areas of weakness in the documentation
        *   Work with account managers/onboarding specialists.
        *   Forum feedback
        *   Establish cadence for input for feedback: parallel with release cadence
    *   Longer term:
        *   Implement "Was this topic helpful? Y/N" in documentation. This includes setting up processes for interpreting and acting on feedback.
        *   Implement usage metrics for SPDS content. 
        *   Previous research showed that gathering and reporting these metrics would either require significant monetary outlay \(AWS doc team model\) or changing our authoring/publishing model to that of Seller Central to leverage their metrics gathering and reporting.


Minimum feedback using thumb up/down mechanism.  


3. Work with your teammates to deliver a business document for peer and leadership review (in a meeting) that defines an agreed-upon project that can be completed by the end of Q2 2019.
Focus Areas: Focus Areas: Ownership/Bias for Action/Deliver Results/Earn Trust	Present a polished document to a meeting of your peers and leadership that fulfills outlined requirements by 3/20/19	As defined in the Technical Writer Role Guidelines, an L5 Technical Writer must identify opportunities to improve processes and drive the necessary changes, as well as contribute to product-wide design decisions and documentation improvement discussions.

*   Include the long term vision, phasing, and rollout plan, and explore the justification behind the recommendation including options you considered and the benefits and tradeoffs of each, risks associated with your recommendation as well as potential technical debt incurred by adopting this approach, acceptance criteria for the final implementation, and a closed-loop method for measuring data and implementing changes based on the results.  

*   Facilitate owning the document while respecting and incorporating the ideas and feedback of your peers and stakeholders.  

*   Incorporate resulting feedback into your final document.  

*   Identify and verify the audience for your final meeting with me early enough in the process to ensure attendance.  

*   On 20-Mar-2019, present the final document to peers and leadership, and facilitate the meeting and discussion.
This will be measured by the above criteria, my observation and assessment of your performance, as well as feedback from key stakeholders.  

