{
  "recommendationCategory": "HighAvailability",
  "recommendationSubCategory": "serviceretirement",
  "recommendationImpact": "serviceretirement",
  "recommendationFriendlyName": "loremIpsum",
  "recommendationTypeId": "5efa5efa-5efa-5efa-5efa-5efa5efa5efa",
  "recommendationMetadataState": "Active",
  "aprlID": "0000a000-0000-0000-0000-000004000000",
  "version": 1.0,
  "description": "ipsum lorem alpha"
  "longDescription": "background info. do ippsum lorem alpha for other.",
  "potentialBenefits": "does stuff.",
  "actions": [
    {
      "description": "do psum lorem alpha other",
    }
  ],
  resourceMetadat": {
    "action": {
      "description": "do psum lorem alpha",
    }
  },
  "displayLabel": "ipsum lorem alpha",
  "tip": "do ippsum lorem alpha for other."  
}
