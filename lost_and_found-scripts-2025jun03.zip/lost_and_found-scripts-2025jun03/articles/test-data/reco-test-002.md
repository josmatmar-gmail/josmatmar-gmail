{
  "recommendationCategory": "Cost",
  "recommendationSubCategory": "serviceretirement",
  "recommendationImpact": "serviceretirement",
  "recommendationFriendlyName": "loremIpsum009",
  "recommendationTypeId": "58d958d9-58d9-58d9-58d9-58d958d958d9",
  "recommendationMetadataState": "Disabled",
  "aprlID": "0000a000-0000-0000-0000-000006000000",
  "version": 1.7,
  "description": "ipsum lorem beta"
  "longDescription": "background info. do ippsum lorem beta for other.",
  "potentialBenefits": "Offers to do stuff.",
  "actions": [
    {
      "description": "do psum otter lorem beta other",
    }
  ],
  resourceMetadat": {
    "action": {
      "description": "do psum lorem beta",
    }
  },
  "displayLabel": "ipsum lorem beta form",
  "tip": "do ippsum lorem beta for other."  
}
