{
  "recommendationCategory": "OperationalExcellence",
  "recommendationSubCategory": "serviceretirement",
  "recommendationImpact": "serviceretirement",
  "recommendationFriendlyName": "loremIpsum045",
  "recommendationTypeId": "51ad51ad-51ad-51ad-51ad-51ad51ad51ad",
  "recommendationMetadataState": "Active",
  "aprlID": "0000a000-0000-0000-0a00-000009000000",
  "version": 27.0,
  "description": "ipsum lorem gamma"
  "longDescription": "background info. do ippsum lorem gamma for other.",
  "potentialBenefits": "Offers to do nothing.",
  "actions": [
    {
      "description": "do psum otter lorem gamma other",
    }
  ],
  resourceMetadat": {
    "action": {
      "description": "do psum lorem gamma",
    }
  },
  "displayLabel": "ipsum lorem gamma form",
  "tip": "do ippsum lorem gamma for other."  
}
