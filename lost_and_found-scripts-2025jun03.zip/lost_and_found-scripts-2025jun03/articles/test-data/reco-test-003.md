{
  "recommendationCategory": "Performance",
  "recommendationSubCategory": "serviceretirement",
  "recommendationImpact": "serviceretirement",
  "recommendationFriendlyName": "loremIpsum045",
  "recommendationTypeId": "s3d2s3d2-s3d2-s3d2-s3d2-s3d2s3d2s3d2",
  "recommendationMetadataState": "Active",
  "aprlID": "0000a000-0000-0000-0a00-000007000000",
  "version": 27.0,
  "description": "ipsum lorem gamma"
  "longDescription": "background info. do ippsum lorem gamma for other.",
  "potentialBenefits": "Offers to do nothing.",
  "actions": [
    {
      "description": "do psum otter lorem gamma other",
    }
  ],
  resourceMetadat": {
    "action": {
      "description": "do psum lorem gamma",
    }
  },
  "displayLabel": "ipsum lorem gamma form",
  "tip": "do ippsum lorem gamma for other."  
}
