#!/bin/bash

# search files in directory

debug=0
searchState="recommendationTypeId"

workingDirectory="/Users/martinj/Documents/GitHub/MicrosoftDocs/lost_and_found/articles"
outputDirectory="$workingDirectory/output"

main() {
    # string directory m_parameter_1
    # string option m_parameter_2

    if [[ -d $1 ]]; then
        m_parameter_1=$1

        if [[ -n $2 ]]; then
            m_parameter_2=$2

            for child in $m_parameter_1/*; do
                if [[ -d $child ]]; then
                    ./search
                elif [[ -f $child ]]; then
                    ./searchContentInFile.sh "$child" "$m_parameter_2"
                fi
            done
        else
            if [[ "$debug" -gt "0" ]]; then
                printf "ERROR: %s\n" "\`option\` not provided to \`main()\`"
            fi
        fi
    else
        if [[ "$debug" -gt "0" ]]; then
            printf "ERROR: %s\n" "\`directory\` not provided to \`main()\`"
        fi
    fi
}

# main "$1" "$2" > $outputDirectory/ssd-"$(date +%Y%b%d-%H%M)".txt
main "$1" "$2"
