#!/bin/bash

# search if Type ID exists in file

debug=0
searchState="recommendationTypeId"

workingDirectory="/Users/martinj/Documents/GitHub/MicrosoftDocs/lost_and_found/articles"
outputDirectory="$workingDirectory/output"

main() {
    # string file m_parameter_1
    # string type id m_parameter_2

    if [[ -f $1 ]]; then
        m_parameter_1=$1

        if [[ -n $2 ]]; then
            m_parameter_2=$2
            m_stateTemp="\"$searchState\": \"$m_parameter_2\""

            if grep -iqw "$m_stateTemp" "$m_parameter_1"; then
                if [[ "$debug" -gt "0" ]]; then
                    printf "%s" "\`$m_stateTemp\` found \`$m_parameter_1\`"
                fi

                printf "%s" "match"
            else
                if [[ "$debug" -gt "0" ]]; then
                    printf "%s" "\`$m_stateTemp\` not found \`$m_parameter_1\`"
                fi

                printf "%s" "nomatch"
            fi
        else
            if [[ "$debug" -gt "0" ]]; then
                printf "ERROR: %s\n" "\`Type ID\` not provided to \`main()\`"
            fi
        fi
    else
        if [[ "$debug" -gt "0" ]]; then
            printf "ERROR: %s\n" "\`file\` not provided to \`main()\`"
        fi
    fi

}

# main "$1" "$2" > $outputDirectory/stiif-"$(date +%Y%b%d-%H%M)".txt
main "$1" "$2"