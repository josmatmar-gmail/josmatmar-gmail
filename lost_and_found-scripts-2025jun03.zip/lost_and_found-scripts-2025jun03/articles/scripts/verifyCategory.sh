#!/bin/bash

# verify value matches category

debug=0
categoryArr=( "Cost" "HighAvailability" "OperationalExcellence" "Performance" )
categoryHashArr=( "cost" "ha" "rel" "opex" "perf" "all" )

workingDirectory="/Users/martinj/Documents/GitHub/MicrosoftDocs/lost_and_found/articles"
outputDirectory="$workingDirectory/output"

main() {
    # string category m_parameter_1

    if [[ -n $1 ]]; then
        m_parameter_1=$1

        if [[ "$m_parameter_1" = "${categoryHashArr[5]}" ]]; then
            printf "%s" "${categoryArr[0]} ${categoryArr[1]} ${categoryArr[2]} ${categoryArr[3]}"
        elif [[ "$m_parameter_1" = "${categoryHashArr[0]}" ]]; then
            printf "%s" "${categoryArr[0]}"
        elif [[ "$m_parameter_1" = "${categoryHashArr[1]}" || "$m_parameter_1" = "${categoryHashArr[2]}" ]]; then
            printf "%s" "${categoryArr[1]}"
        elif [[ "$m_parameter_1" = "${categoryHashArr[3]}" ]]; then
            printf "%s" "${categoryArr[2]}"
        elif [[ "$m_parameter_1" = "${categoryHashArr[4]}" ]]; then
            printf "%s" "${categoryArr[3]}"
        else
            if [[ "$debug" -gt "0" ]]; then
                printf "ERROR: %s\n" "\`category\` does not match values"
                printf "  USE: %s\n" "verifyCategory.sh \"<category>\""
                printf "         %s\n" "\`${categoryHashArr[0]}\` for \`${categoryArr[0]}\`"
                printf "    %s\n" "\`${categoryHashArr[1]}\`, \`${categoryHashArr[2]}\` for \`${categoryArr[1]}\`"
                printf "         %s\n" "\`${categoryHashArr[3]}\` for \`${categoryArr[2]}\`"
                printf "         %s\n" "\`${categoryHashArr[4]}\` for \`${categoryArr[3]}\`"
            fi

            printf "%s" "nomatch"
        fi
    else
        if [[ "$debug" -gt "0" ]]; then
            printf "ERROR: %s\n" "\`category\` not provided to \`main()\`"
        fi
    fi
}

# main "$1" > $outputDirectory/vc-"$(date +%Y%b%d-%H%M)".txt
main "$1"