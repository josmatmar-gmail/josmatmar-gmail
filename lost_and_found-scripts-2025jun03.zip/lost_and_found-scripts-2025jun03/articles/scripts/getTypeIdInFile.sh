#!/bin/bash

# return value if typeid metadata exists in file

debug=0
searchTypeId="recommendationTypeId"
guidPattern='^\{?[A-Z0-9a-z]{8}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{12}\}?$'

workingDirectory="/Users/martinj/Documents/GitHub/MicrosoftDocs/lost_and_found/articles"
outputDirectory="$workingDirectory/output"

main() {
    # string file m_parameter_1

    if [[ -f $1 ]]; then
        m_parameter_1=$1

        if m_lineTypeID=$(grep "$searchTypeId" "$m_parameter_1"); then
            if [[ "$debug" -gt "0" ]]; then
                printf "%s\n" "\`$searchTypeId\` found \`$m_parameter_1\`"
                printf "%s\n" "$m_lineTypeID"
            fi
            
            m_valueTypeID=$(printf "%s" "$m_lineTypeID" | cut -d '"' -f 4)

            if [[ "$m_valueTypeID" =~ $guidPattern ]]; then
                printf "%s" "$m_valueTypeID"
            else
                if [[ "$debug" -gt "0" ]]; then
                    printf "%s\n" "\`$searchTypeId\` not valid GUID or UUID \`$m_parameter_1\`"
                fi

                printf "%s" "nomatch"
            fi
        else
            if [[ "$debug" -gt "0" ]]; then
                printf "%s\n" "\`$searchTypeId\` not found \`$m_parameter_1\`"
            fi

            printf "%s" "nomatch"
        fi
    else
        if [[ "$debug" -gt "0" ]]; then
            printf "ERROR: %s\n" "\`file\` not provided to \`main()\`"
        fi
    fi
}

# main "$1" "$2" > $outputDirectory/gtiif-"$(date +%Y%b%d-%H%M)".txt
main "$1" "$2"
