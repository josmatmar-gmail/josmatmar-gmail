ECHO Running 
ECHO aws s3 sync --delete --region us-east-1 --exclude "%MWS_HOME%\_out\master\docs.html" "%MWS_HOME%\_out\master" "s3://docs.developer.amazonservices.com"

aws s3 sync --delete --region us-east-1 --exclude "%MWS_HOME%\_out\master\docs.html" "%MWS_HOME%\_out\master" "s3://docs.developer.amazonservices.com"
