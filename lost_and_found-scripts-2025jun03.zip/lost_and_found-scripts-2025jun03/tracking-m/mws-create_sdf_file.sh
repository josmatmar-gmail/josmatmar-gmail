# !/bin/bash

# sysinfo_page - A script to produce sdf index file from html

MWS_HTML="/c/mws/_out"
MWS_HTML_OUT="$MWS_HTML/master"
MWS_HTML_AU="$MWS_HTML_OUT/en_AU"
MWS_HTML_CA="$MWS_HTML_OUT/en_CA"
MWS_HTML_CN="$MWS_HTML_OUT/zh_CN"
MWS_HTML_DE="$MWS_HTML_OUT/en_DE"
MWS_HTML_ES="$MWS_HTML_OUT/en_ES"
MWS_HTML_FR="$MWS_HTML_OUT/en_FR"
MWS_HTML_IN="$MWS_HTML_OUT/en_IN"
MWS_HTML_IT="$MWS_HTML_OUT/en_IT"
MWS_HTML_JP="$MWS_HTML_OUT/ja_JP"
MWS_HTML_MX="$MWS_HTML_OUT/en_MX"
MWS_HTML_UK="$MWS_HTML_OUT/en_UK"
MWS_HTML_US="$MWS_HTML_OUT/en_US"
MWS_SDF="/c/_out_sdf/master"

epoch_time="$(($(date +%s000)/1000))"

## if [ -d MWS_HTML_US ]; then 
## /c/mws/_out/master/en_CA /c/mws/_out/master/en_MX /c/mws/_out/master/en_UK /c/mws/_out/master/en_DE /c/mws/_out/master/en_ES /c/mws/_out/master/en_FR /c/mws/_out/master/en_IN /c/mws/_out/master/en_IT /c/mws/_out/master/en_AU /c/mws/_out/master/ja_JP /c/mws/_out/master/zh_CN )


    if [ -d $MWS_SDF ]; then 
        echo "Delete $MWS_SDF directory"
        rm -fr $MWS_SDF
    fi

    echo "Create $MWS_SDF directory"
    mkdir $MWS_SDF
    
    echo "Copy contents of $MWS_HTML_US to $MWS_SDF directory"
    cp -fr $MWS_HTML_US/* $MWS_SDF

    echo "Modify content of $MWS_SDF directory for CloudSearch"
    python /c/mws/git/build_tools/build_html/bin/ModifyHtmlForCloudSearch.py $MWS_SDF $MWS_HTML_US

    echo "Generate sdf file for $MWS_SDF directory at $epoch_time"
    echo "$MWS_SDF/**/*.html --> $MWS_SDF"
    /c/mws/git/build_tools/CloudSearch/v2011-02-01/bin/cs-generate-sdf.cmd -s $MWS_SDF/**/*.html -o $MWS_SDF -dv $epoch_time

    ##echo "Update sdf file to indicate Prod build"
    ## python /c/mws/git/build_tools/build_html/bin/UpdateSDF.py $MWS_SDF/1.sdf prod

    ##echo "Clean up CloudSearch log"
    ##rm -fr ./cstools.general.log*
## else
##    echo "$MWS_HTML_US directory does not exist"
## fi 
