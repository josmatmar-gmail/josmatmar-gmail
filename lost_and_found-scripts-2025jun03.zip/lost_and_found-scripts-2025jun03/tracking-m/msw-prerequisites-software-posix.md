# Software to install (posix)  

**NEEDS UPDATES FOR MAC AND LINUX**

In order to build HTML documentation on your computer, you will need to install the following software:  

## Java JDK.  
*   Latest release of version 8. To install:  
    1.  Go to [oracle.com/technetwork/java/javase/downloads](https://www.oracle.com/technetwork/java/javase/downloads/index.html).  
        1.  Search for `JDK`.  
        2.  Click on *Download* button.  
    2.  On the JDK downloads page, click on the *Accept License Agreement* radio button.  
        1.  Search for `Windows x64`.  
        2.  Click on the download link.  
    3.  After downloading, install java.  
        *   **NOTE**: The Java Development Kit is updated frequently, and that you will have to update `C:\mws\git\build_tools\build_html\startcmd.bat` every time a new Java Development Kit is released. Specifically, you will need to update the `JAVA_HOME` environment variable to point to the latest version of the Java Development Kit.  

## Python.  
*   Latest release of version 2.6.5+ or version 3.3+. To install:  
    1.  Go to [python.org/downloads/windows/](https://www.python.org/downloads/windows/).  
        2.  Search for `Windows x86-64`.  
        3.  Click on the installer download link.  
    2.  After downloading, install python.  
        *   **NOTE**: When installing, accept all the defaults. Make sure the install path is set to `C:\Python$$`.  

## Git.  
*   To install:  
    1.  Go to [git-scm.com/download/win](https://www.git-scm.com/download/win).  
        1.  Download the 64-bit version of Git for Windows.  
    2.  After downloading, install Git.  

## AWS Command Line Interface.  
*   To install:  
    1.  Go to [aws.amazon.com/cli](https://aws.amazon.com/cli).  
        1.  Download the 64-bit version of AWS Command Line Interface Tools for Windows.  
    2.  After downloading, install AWS CLI.  
        *   **NOTE**: When installing, select all the defaults. Verify the install path is set to `C:\Program Files\Amazon\AWSCLI`.  
        *   If you have permission to post HTML files to S3 and index files to CloudSearch, set the `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` environment variables to the correct values.  

## Visual Studio Code.  
*   To install:  
    1.  Go to [code.visualstudio.com/#alt-downloads](https://code.visualstudio.com/#alt-downloads).  
        1.  Download the 64-bit version of Visual Studio Code for Mac.  
    2.  After downloading, install Visual Studio Code.  

## OxygenXML.  
*   To install:  
    1.  Go to [oxygenxml.com/xml_editor/download_oxygenxml_editor.html](https://www.oxygenxml.com/xml_editor/download_oxygenxml_editor.html).  
        1.  Click on the windows tab.  
        2.  Download the Windows 64-bit version of Oxygen XML Editor.  
    2.  After downloading, install Oxygen XML Editor.  
    3.  Run the application from the product installation directory.  
    4.  Copy the license key you received by email and paste it in the license registration dialog box.  

