# Configuring PuTTY for SSH (Windows)  

To avoid having to enter your Amazon password multiple times for a single Git operation, you can install PuTTY and edit your PuTTY configuration.  

## Install Putty  

1.  Visit [www.putty.org](www.putty.org).  
    1.  Click on the *You can download PuTTY [here](https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html)* link.  
    2.  Download the 64-bit Windows installer.  
    3.  Run the installer.  

## Create Symbolic Link  

1.  Click on the Start icon.  
    1.  Type `cmd`.  
    2.  Right-click on *Command Prompt* and choose *Run as administrator*.  
2.  On the Command prompt.
    1.  Type `chdir`.  
    2.  Type `mklink /D "C:\PuTTY" "C:\Program Files\PuTTY"`.  
        *   You should see `symbolic link created for C:\PuTTY <<===>> C:\Program Files\PuTTY`. 
            *   **NOTE**: If you get a `The syntax of the command is incorrect` error from cutting and pasting the above, then try re-typing it manually.  
    3.  Exit the command prompt.  

## Edit Environment Variables  

1.  Click on the Start icon.  
    1.  Type `env`.  
    2.  Click on *Edit the system environment variables*.  
2.  On the *System Properties* window.  
    1.  Click on *Environment Variables...* button.  
3.  On the *Environment Variables* window, under *User variables for ...*.  
    1.  Search for `GIT_SSH` variable.  
        *   If not found, then click on *New* button.  
        *   If found, then click on *Edit* button.  
        
        | Name | Value |  
        |:--- |:--- |  
        | `GIT_SSH` | `C:\PuTTY\plink.exe` |  

        Click on *OK* button.  
    2.  Search for `HOME` variable.  
        *   If not found, then click on *New* button.  
        *   If found, then click on *Edit* button.  
        
        | Name | Value |  
        |:--- |:--- |  
        | `HOME` | `%USERPROFILE%` |  
        
        Click on *OK* button.  
4.  On the *System Properties* window, click on *OK* button and close the dialog.  

## Test Environment Variables  
1.  Click on the Start icon.  
    1.  Type `cmd`.  
    2.  Right-click on *Command Prompt* and choose *Run as administrator*.  
2.  On the Command prompt.
    2.  Type `%GIT_SSH%`.  
        *   You should see help text from plink.exe.  
            
            ![plink help text](/images/logo.png)

##  Setting for PuTTY to Cache the GitFarm Server Credentials.  
    
**NOTE**: The following steps are completely plagiarized from [w.amazon.com/index.php/BuilderTools/Product/GitFarm/UserGuide/NonRhelPlatforms#Workaround:_Windows](https://w.amazon.com/index.php/BuilderTools/Product/GitFarm/UserGuide/NonRhelPlatforms#Workaround:_Windows)  
    
1.  Open PuTTY.  
    1.  Under *Category*.  
        1.  Expand *Connection*.  
            1.  Click on *Data*.  
                *   Under *Login Details*.  
                    *   In the *Auto-login Username* textbox, enter your Amazon alias.  
            2.  Click on *Proxy*.  
                *   Under *Proxy type*, verify the *None* radio button is selected.  
            3.  Expand *SSH*.
                1.  Expand *Auth*.  
                    1.  Click on *GSSAPI*.  
                        *   Verify the *Attempt GSSAPI authentication (SSH-2 only)* checkbox is selected.  
    2.  Under *Load, save, or delete session*.  
        1.  Click on *Session*.   
            1.  Select `Default Settings`.  
            2.  Click on *Save* button.  

## Test Connections  

1.  [Connection to GitFarm on Port 22](#connection-to-gitfarm-on-port-22)  
2.  [Connection to GitFarm on Port 2222](#connection-to-gitfarm-on-port-2222)  

### Connection to GitFarm on Port 22  

*   Open Open connection `git.amazon.com:22` using command prompt.  
    1.  Click on the Start icon.  
        1.  Type `cmd`.  
        2.  Right-click on *Command Prompt* and choose *Run as administrator*.  
    2.  On the Command prompt.  
        1.  Run the following command.  
                
            ``` shell
            plink -P 22 git.amazon.com
            ```  
            
        2.  Choose `y` to store key in cache.  
*   Open connection `git.amazon.com:22` using *Putty Configuration* window.  
    1.  Under *Specify the destination you want to connect to*.  
        
        | Field | Value |  
        |:--- |:--- |  
        | Host Name (or IP address) | `git.amazon.com` |  
        | Port | `22` |  

    2.  Click on *Open* button.
    3.  PuTTY should ask you to accept the certificate fingerprint; save it now.  

### Connection to GitFarm on Port 2222  

*   Open connection `git.amazon.com:2222` using command prompt.  
    1.  `plink -P 2222 git.amazon.com`
    2.  choose `y` to store key in cache.
*   Open connection `git.amazon.com:2222` using *Putty Configuration* window.  
    1.  Under *Specify the destination you want to connect to*.  
        
        | Field | Value |  
        |:--- |:--- |  
        | Host Name (or IP address) | `git.amazon.com` |  
        | Port | `2222` |  

    2.  Click on *Open* button.
    3.  PuTTY should ask you to accept the certificate fingerprint; save it now.  
