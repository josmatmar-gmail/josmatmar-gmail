# Configuring SSH (posix)  

To avoid having to enter your Amazon login password multiple times for a single Git operation, you can install PuTTY and/or edit your PuTTY configuration.  

7.  Test connections using SSH.  
    1.  *   Open connection `git.amazon.com:22` using bash shell.  
            1.  `ssh -p 22 git.amazon.com`
            2.  choose `yes` to store key in cache.
    2.  *   Open connection `git.amazon.com:2222` using bash shell.  
            1.  `ssh -p 2222 git.amazon.com`
            2.  choose `yes` to store key in cache.
            