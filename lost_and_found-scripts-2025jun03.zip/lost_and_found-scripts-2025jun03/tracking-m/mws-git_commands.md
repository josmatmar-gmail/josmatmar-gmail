# Git Commands | MWS DevEx

| Command | Action | Page in Pro Git |  
|:--- |:--- | ---:|  
| `git status` | Checks the status of the files in the branch you are on | 46 |  
| `git commit -am "[commit message]"` | Stages and commits the modified files in the working directory | 54, 55, 137 |  
| `git log -6` | Views a log of the last six commits in the current branch | 58 |  
| `git remote` | Shows your remote repositories | 69 |  
| `git remote show origin` | Gets more information about your remote repositories. | 72 |  
| `git branch [branch_name]` | Creates a new branch called `[branch_name]` | 90 |  
| `git checkout [branch_name]` | Switches to the `[branch_name]` branch | 90 |  
| `git checkout -b [branch_name]` | Creates a new branch called `[branch_name]` and switches to that branch (shortcut for "`git branch [branch_name]`" followed by "`git checkout [branch_name]`") | 90 |  
| `git merge [branch_name]` | Merges the `[branch_name]` branch into the branch you that you have checked out.<br /> Before executing this command, check out the branch that you want to merge into. | 92 |  
| `git branch -d [branch_name]` | Deletes the `[branch_name]` branch.<br /> You must check out a different branch before you can execute this command | 93 |  
| `git branch` | Lists your branches | 99 |  
| `git branch -v` | Lists your branches with the last commit for each branch | 99 |  
| `git push origin [branch_name]` | Creates a remote branch named `[branch_name]` on origin | 109 |  
| `git push -u origin [branch_name]` | Creates a remote branch named `[branch_name]` on origin.<br /> The –u parameter makes sure your local branch is tracking the new remote branch.<br /> This means you can issue "`git pull`" or "`git push`" commands with no other arguments. |  |  
| `git fetch origin` | Creates pointers to remote branches on origin that you don't yet have.<br /> Does not check out any of the remote branches.<br /> To check out the remote branches, execute "`git checkout --track origin/[branch_name]`".<br /> Also use this before executing "`git status`" to bring down changes from origin. | 71, 106, 110 |  
| `git checkout --track origin/[branch_name]` | Creates a local "tracking branch" that tracks the `origin/[branch_name]` branch, which was pushed to origin by someone else. | 111 |  
| `git push origin --delete [branch_name]` | Deletes the `[branch_name]` branch from the server. | 113 |  
| `git pull` | Shortcut for fetching from origin master and then merging into local master.<br /> Looks up the server and branch that your current branch is tracking, fetches from that server, and then tries to merge into your current branch.<br /> Works for for local master (which tracks origin master) or any other branch that you have set up to track a remote branch using "`git checkout --track origin/[branch_name]`". | 113 |  
| `git push origin master` | Pushes local master to origin master | 71 |  

