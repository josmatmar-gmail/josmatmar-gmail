## export CS_HOME=/c/mws/git/build_tools/CloudSearch/v2011-02-01
## export PATH=$PATH;$CS_HOME/bin
## export CS_ENDPOINT=cloudsearch.us-east-1.amazonaws.com


aws s3 sync --delete --region us-east-1 --exclude "/c/mws/_out/master/docs.html" "/c/mws/_out/master" "s3://docs.developer.amazonservices.com"

ECHO aws.exe s3 sync --delete --region us-east-1 --exclude "/c/mws/_out/master/docs.html" "/c/mws/_out/master" "s3://docs.developer.amazonservices.com"

## /c/mws/git/build_tools/CloudSearch/v2011-02-01/bin/cs-post-sdf.cmd --source /c/mws/_out_sdf/master/1.sdf --domain-name mws-htmldocs-prod --access-key $AWS_ACCESS_KEY_ID --secret-key $AWS_SECRET_ACCESS_KEY
cmd /c /c/mws/git/build_tools/CloudSearch/v2011-02-01/bin/cs-post-sdf.cmd --source /c/mws/_out_sdf/master/1.sdf --domain-name mws-htmldocs-prod --access-key $AWS_ACCESS_KEY_ID --secret-key $AWS_SECRET_ACCESS_KEY

ECHO cmd /c /c/mws/git/build_tools/CloudSearch/v2011-02-01/bin/cs-post-sdf.cmd --source /c/mws/_out_sdf/master/1.sdf --domain-name mws-htmldocs-prod --access-key $AWS_ACCESS_KEY_ID --secret-key $AWS_SECRET_ACCESS_KEY

