ECHO Running 
ECHO cmd /c c:\mws\git\build_tools\CloudSearch\v2011-02-01\bin\cs-post-sdf.cmd --source c:\mws\_out_sdf\master\1.sdf --domain-name mws-htmldocs-prod --access-key %AWS_ACCESS_KEY_ID% --secret-key %AWS_SECRET_ACCESS_KEY%

cmd /c c:\mws\git\build_tools\CloudSearch\v2011-02-01\bin\cs-post-sdf.cmd --source c:\mws\_out_sdf\master\1.sdf --domain-name mws-htmldocs-prod --access-key %AWS_ACCESS_KEY_ID% --secret-key %AWS_SECRET_ACCESS_KEY%
