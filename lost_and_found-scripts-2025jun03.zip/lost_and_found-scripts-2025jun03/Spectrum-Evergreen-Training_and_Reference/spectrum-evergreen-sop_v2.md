# Spectrum - Evergreen Instructions  

**Contents**  
*   [Requirements](#requirements)  
*   [Software to Install](#software-to-install)  
*   [Setting Your Security Certificate](#setting-your-security-certificate)  
*   [Git Command Line](#git-command-line)  
*   [Clone Repo to Local Machine](#clone-repo-to-local-machine)  
*   [Create Branch](#create-branch)  
*   [Add Content to a Branch](#add-content-to-a-branch)  
*   [Preview Content](#preview-content)  
*   [Merge Content in Mainline Branch](#merge-content-in-mainline-branch)  
*   [\[Alternate\] Add Content to a Branch](#alternate-add-content-to-a-branch)  
*   [To-Do](#to-do)  
 
---  

## Requirements  

In order to access the repository on your local machine, please verify that you meet the following requirements.  

*   Computer running Windows, macOS, or Linux.  
*   Have ssh token set up on your local machine.  
*   Permissions to the following groups and bindles
    *   [apolloop](https://permissions.amazon.com/group.mhtml?target=12071) \(posix\)
    *   [apolloop-misc](https://permissions.amazon.com/group.mhtml?target=1981061) \(posix\)
    *   [SpectrumCM](https://bindles.amazon.com/software_app/SpectrumCM) \(Bindle\)


## Verify repo access  

Verify that you have access to the repository using **Code Browser**.  

1.  While connected to the Amazon network, visit the Spectrum-Evergreen-Content package Permissions page at [code.amazon.com/packages/Spectrum-Evergreen-Content/permissions](https://code.amazon.com/packages/Spectrum-Evergreen-Content/permissions) in Amazon Code Browser.  
2.  Verify your user name  `does have` full control of this package and `does have` read permissions for this package.  


---  

## Software to Install  

The following software provides a consistent baseline for viewing, adding, and updating the markdown files that make up our Evergreen site.  

**Sections**   
*   [Amazon WorkDocs](#amazon-workdocs)  
*   [Git](#git)  
*   [Editor for Markdown](#editor-for-markdown)  

---  

### Amazon WorkDocs  

Provides local access to WorkDocs \(W:\).  

| Software | Download | Installation Notes |  
|:--- |:--- |:--- |  
| Amazon Workdocs Drive App | [amazonworkdocs.com/apps.html](https://amazonworkdocs.com/apps.html) |  |


### Git  

> **NOTE**: Installing Git \(git-scm\) includes the git-bash command-line.  

| Software | Download | Installation Notes |  
|:--- |:--- |:--- |  
| Git 64-bit | [git-scm.com/downloads](https://git-scm.com/downloads) | Windows directory: `C:\Program Files\Git` |  
| Desktop | [desktop.github.com](https://desktop.github.com) | [GitHub Desktop User Guides](https://help.github.com/desktop/guides) |  


### Editor for Markdown  

> **NOTE**: Visual Studio Code offers several advantages over NotePad++.  
> However you may use whatever text editor for updating markdown files.  

| Software | Download | Installation Notes |  
|:--- |:--- |:--- |  
| Visual Studio Code | [code.visualstudio.com/download](https://code.visualstudio.com/download) | Install additional plug-ins. |  
| Markdown PDF | Install within Visual Studio Code | Github repo: [github.com/yzane/vscode-markdown-pdf](https://github.com/yzane/vscode-markdown-pdf) |  
| NotePad++ | Software Center |  |  


---  


## Setting Your Security Certificate  


### Install git-scm for Windows

Plagiarized from [w.amazon.com/index.php/Git/ManualGitInstall#Installing_on_Windows](https://w.amazon.com/index.php/Git/ManualGitInstall#Installing_on_Windows)

> **To install the latest version of Git for Windows**  
>
> 1.  Go to the [Git website](http://git-scm.com) and click **Download for Windows** under **Latest Stable Release**.  
> 2.  Download the EXE file to your desktop.  
> 3.  Double-click the EXE file, and then click **Run**.  
> 4.  Type your alias and password into the **User Account control box**, and click **Yes**.  
> 5.  proceed with the set up instructions  
> 6.  When the installer asks whether to use Git SSH (default selection) or plink.exe, leave the radio box on Git SSH  
> 7.  When the Git installer asks you about line endings, you should select '**Checkout as-is, commit Unix-style line endings**'. If you ask Git to convert everything to Windows line endings for you, some regression tests may fail because they assume their data files will have Unix line endings.  
>     *   If you forgot and this is happening, edit `%USERPROFILE%/.gitconfig` and add the following line at the top:  
>         *   `core.autocrlf = input`  
>     *   Now remove all files and check them out again: `git rm --cached -r S9DmCampaignsServiceRegressionTests; git reset --hard`  
> 8.  Run `git config --system core.longpaths true` to make sure git handles long paths properly.  
> 9.  Next you may want to check out the [Using Git on Windows wiki](https://w.amazon.com/index.php/Git/Windows)  

---  

### Accept security certificate  

Accept security certificate for the package uri.  

Plagiarized from [w.amazon.com/index.php/BuilderTools/Product/GitFarm/UserGuide/NonRhelPlatforms#Workaround:_Windows](https://w.amazon.com/index.php/BuilderTools/Product/GitFarm/UserGuide/NonRhelPlatforms#Workaround:_Windows)

> With the newer GitFarm configuration, all that should be needed to make password-less git working is to follow these steps:  
> 1.  Install the Git command line using these instructions: [Git/ManualGitInstall](https://w.amazon.com/index.php/Git/ManualGitInstall).  
> 2.  Install the PuTTY suite \(see [PuTTY](https://w.amazon.com/index.php/PuTTY)\).  
> 3.  Set up a few environment variables.  
>     *   Type "environment" into the Start menu and choose "Edit environment variables for your account".  
>     *   Set the `HOME` variable to be `%USERPROFILE%` so that Git doesn't try to store stuff on your networked home drive.  
>     *   Set the `GIT_SSH` variable to be the complete path to `plink.exe` \(by default, `%ProgramFiles%\PuTTY\plink.exe`\) to make sure you're using an SSH client with Kerberos support. \(It also works, if `plink.exe` is in your path, to set `GIT_SSH=plink`\).  
>         *   @mahdis The path for `GIT_SSH` should have no spaces. This worked for me: `GIT_SSH=C:\Putty\plink.exe`  
>         *   @jerosenf The path for `GIT_SSH` can have spaces if you run git from a Windows cmd window rather than bash.  
>         *   @scotboyd `mklink /d "C:\PuTTY" "C:\Program Files (x86)\PuTTY"` works wonders if you have things that expect PuTTY in Program Files.  
>         *   @sthood I found that Git (2.15.something) still doesn't like the directory symbolic link in Git Bash. I wound up moving the PuTTY install into the root C: location. Only then did everything work correctly from a Git Bash shell.  
> 4.  Set Git's working directory so it doesn't try to store stuff on your Networked home drive.  
>     *   Type "git" into the Start menu and right-click the "Git Bash" shortcut.  
>         *   \(In Windows 10, right click the Git Bash shortcut in the start menu and click Open File Location in order to open the related Start Menu folder. From there, right-click the Git Bash shortcut and click Properties\)  
>     *   Go into "Properties" and set "Start in" to `%HOME%`.  
> 5.  Configure PuTTY/plink to set your username so that Kerberos works. Open PuTTY and:  
>     *   Select Connection > Data, and and enter username in the **Auto-login Username** field.  
>     *   Under Connection > SSH > Auth > GSSAPI, ensure that **Attempt GSSAPI authentication** is selected. **This is the default**  
>         *   @bomeyers If you have a path to a private key file specified in Connection > SSH > Auth, Git will try and fail to use that (instead of Kerberos). This path must be empty.  
>     *   Under Connection > Proxy, ensure that this session has "Proxy type" set to "None". **This is the default**  
>     *   Under Session, select "Default Settings" and click Save.  
>     *   Finally, attempt to open a connection from within PuTTY to `git.amazon.com`. PuTTY should ask you to accept the certificate fingerprint; save it now. Repeat for `git.amazon.com:2222` if your repositories refer to that port number.  
>         *   Or, use `plink.exe` from the command line (e.g. `plink -P 2222 git.amazon.com`) and choose 'y' to store key in cache.  
>         *   @patchin I had to run `plink -agent git.amazon.com` to get the fingerprint to cache correctly before running git clone.  
>
> And that should do it.  


---  

## Git Command Line  

> **Check Git Version** 
> 
> ```shell
> git --version
> ```  

> **Pull from Remote Server**  
>
> > **NOTE**: the name of the **master** branch is "`mainline`".  
>
> ```shell
> git pull origin mainline
> ```  

> **Create Branch and Attach to Remote Server**  
>
> > **Create Branch**  
> >
> > ```shell
> > git branch [branch_name]
> > ```  
>
> > **Open Branch**  
> >
> > ```shell
> > git checkout [branch_name]
> > ```  
>
> > **Attach Branch to Remote Server**  
> >
> > ```shell
> > git push -u origin [branch_name]
> > ```  
>


---   

## Clone Repo to Local Machine  

In WEB BROWSER.  
1.  While connected to the Amazon network, visit the Spectrum-Evergreen-Content package at [code.amazon.com/packages/Spectrum-Evergreen-Content](https://code.amazon.com/packages/Spectrum-Evergreen-Content) in Amazon Code Browser.  
2.  In the top-right corner, locate the Clone uri text box and copy the shh uri.  
    
    > **EXAMPLE**: `ssh://git.amazon.com/pkg/Spectrum-Evergreen-Content`  

In GIT DESKTOP.  
1.  Clone a repository by chooseing one of the following methods.    
    *   Select **File** > **Clone Repository...**  
    *   Press `Ctrl`+`Shift`+`O`  
    *   Click on **Current repository** button, click on **Add** button, select **Clone Repository...**  
2.  Select on the **URL** tab.  
    1.  In the **Repository URl or GitHub username and repository** text bow, enter the ssh uri.  
    2.  In the **Local path** test box, enter the following location. 
        *   For Windows: `c:\spectrum\git\Spectrum-Evergreen-Content`  
    3.  Click on **Clone** button.  


---  

## Create Branch  

In GIT DESKTOP.  
1.  Click on **Current repository** and select `Spectrum-Evergreen-Content`.  
2.  Click on **Current branch** 
    1.  Click on **New Branch** button.  
3.  On the **Create a branch** pop-up window.  
    1.  In the **Name** text box, enter the name of your branch.  
        
        > **NOTE**: Use your alias or a SIM identifier.  

    2.  Under *Create branch based on...* section.  
        *   Click on **mainline**.  
    3.  Click on **Create branch** button.  


---  

## Add Content to a Branch  
 
> **Editing on your Desktop**  
>
> In GIT DESKTOP.  
> 1.  Click on **Current repository** and select `Spectrum-Evergreen-Content`.  
> 2.  Click on **Current branch** and select your current branch.  
>     
>     > **NOTE**: Be sure to work in your own branch or in a branch associated with a SIM.  
>
> 3.  Click on **Fetch origin**.  
> 4.  Click on **Open with Visual Studio Code** button.  
> 
> In VISUAL STUDIO CODE.  
> 1.  Edit files.  
> 2.  Save changes.  
>
> In GIT DESKTOP.  
> 1.  Under the **Changes** tab.  
>     1.  Select the checkbox for each chnaged file to attach to the commit.  
>     2.  In the **Summary** text box, enter one of the following messages.  
>         *   `Added content.`  
>         *   `Updated content.`  
>         *   `Removed content.`  
>         *   `Added file.`  
>         *   `Removed file.`  
>     3.  In the **Description** text box, enter a brief summary of changes using past tense active statements.  
>         
>         > **EXAMPLE**: `Updated content per TR feedback. Added links. Removed header.`  
>         
>     4.  Click on **Commit to [branch_name]** button.  
>         
>         > **NOTE**: Be sure to work in your own branch or in a branch associated with a SIM.  
>         
>     5.  Click **Push origin** button.  


## Preview Content  

*   Talk to @martinnx to update the preview for your branch on the Developer Desktop.   
    *   Check: use `brazil build`  
    *   Clean and resync package on Developer Desktop. 
    *   Check: git rebase issues with CRUX  


---  

## Merge Content in Mainline Branch  

> **NOTE**: This step is a work in progress.  

*   Talk to @martinnx to merge your branch into Mainline Branch.    
    *   Check: run `brazil build` on branch   


---  

## \[Alternate\] Add Content to a Branch  

> **Note**:  You must set up your branch before performing these steps.  

In WEB BROWSER.  
1.  While connected to the Amazon network, visit the SPDS API Onboarding site at [evergreen.corp.amazon.com/spds-onboarding](https://evergreen.corp.amazon.com/spds-onboarding).  

> **Editing in Your Web Browser**  
>
> > **IMPORTANT** 
> 
> 1.  Click on the **Edit File Online** icon (located in the top-right corner of each page).  
> 2.  On the **Code Browser** page for the markdown files, under the **Source** tab.  
>     1.  Verify that you are in you branch.  
>         *    The url should display the following.  
>              
>              ```https
>              https://code.amazon.com/packages/Spectrum-Evergreen-Content/trees/heads/[branch_name]
>              ```  
>              
>     2.  In the **FILE CONTENTS** section, on the left side, edit the markdown content.  
>         
>         > **NOTE**: On the right side, the live preview is displayed.  
>         
>     3.  In the **COMMIT MESSAGE** section, enter your commit message.  
>     4.  Click on **Create Commit** button.  
>     5.  Under the **Ready to ship?** section.  
>         *   Select your branch.  
>     6.  Under **Push the changes:** section.  
>         *   Select either merge option.  
>     7.  Click on the **Do Merge** button.  
> Congrats, you now have your changes stored in your branch using a web browser.  


---  

## To-Do

1.  Linters can be added to the pipeline.  
2.  Reviewers can be added to the pipeline.  

