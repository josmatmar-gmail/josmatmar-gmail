# Spectrum - Evergreen Instructions  

**Contents**  
*   [Requirements](#requirements)  
*   [Software to Install](#software-to-install)  
*   [Settings](#setttings)  
*   [Usage](#usage)  


---  

## Requirements  

In order to access the repository on your local machine, please verify that you meet the following requirements.  

*   Computer running Windows, macOS, or Linux.  
*   Have ssh token set up on your local machine.  
*   Permissions to the following groups and bindles
    *   [apolloop](https://permissions.amazon.com/group.mhtml?target=12071) \(posix\)
    *   [apolloop-misc](https://permissions.amazon.com/group.mhtml?target=1981061) \(posix\)
    *   [SpectrumCM](https://bindles.amazon.com/software_app/SpectrumCM) \(Bindle\)

---  

## Software to Install  

The following software provides a consistent baseline for viewing, adding, and updating the markdown files that make up our Evergreen site.  

**Sections**   
*   [Amazon WorkDocs](#amazon-workdocs)  
*   [Git](#git)  
*   [Editor for Markdown](#editor-for-markdown)  

---  

### Amazon WorkDocs  

| Software | Download | Installation Notes |  
|:--- |:--- |:--- |  
| Amazon Workdocs Drive App | [amazonworkdocs.com/apps.html](https://amazonworkdocs.com/apps.html) |  |


### Git  

> **NOTE**: Installing Git \(git-scm\) includes the git-bash CLI.  

| Software | Download | Installation Notes |  
|:--- |:--- |:--- |  
| Git 64-bit | [git-scm.com/downloads](https://git-scm.com/downloads) | Windows directory: `C:\Program Files\Git` |  
| Desktop | [desktop.github.com](https://desktop.github.com) | [GitHub Desktop User Guides](https://help.github.com/desktop/guides) |  


### Editor for Markdown  

> **NOTE**: Visual Studio Code offers several advantages over NotePad++.  
> However you may use whatever text editor for updating markdown files.  

| Software | Download | Installation Notes |  
|:--- |:--- |:--- |  
| Visual Studio Code | [code.visualstudio.com/download](https://code.visualstudio.com/download) | Install additional plug-ins. |  
| Markdown PDF | Install within Visual Studio Code | Github repo: [github.com/yzane/vscode-markdown-pdf](https://github.com/yzane/vscode-markdown-pdf) |  
| NotePad++ | Software Center |  |  

---  

## Settings  

**Sections**   
*   [Set up your SSH key](#set-up-your-ssh-key)  
    *   [Set up SSH shortcut](#set-up-ssh-shortcut)  
*   [Git CLI](#git-cli)  

---  

### Set up your SSH key  

*   To assign you SSH key on your host, see [Set Up Your SSH Key](https://builderhub.corp.amazon.com/docs/cloud-desktop/user-guide/setup-post.html#id2).  

> Set up your initial SSH key  
>
> ```bash
> ssh-keygen
> ```

Accept the defaults, and make sure to give your key a passphrase.  This will create a key in your ~/.ssh directory.  

#### Set up SSH shortcut 

> **NOTE**: This is optional.  

If you are a developer who heavily relies on your Cloud Desktop, even a hostname alias can be a pain to memorize (and especially to type over and over).  
Here’s how to set up an SSH shortcut to avoid typing the full hostname every time you login through SSH.  

> **To set up an SSH shortcut \(Ubuntu and macOS\)**  
>
> Make sure your SSH directory and config file exists:  
>
> ```bash
> ls ~/.ssh/config
> ```  

If it doesn’t, then run the following commands:  

> ```bash
> mkdir ~/.ssh
> touch ~/.ssh/config
> ```  

### Git CLI  

> **Check Git Version** 
> 
> ```shell
> git --version
> ```  

> **Pull from Remote Server**  
>
> > **NOTE**: the name of the *master* branch is "`mainline`".  
>
> ```shell
> git pull origin mainline
> ```  

> **Create Branch and Attach to Remote Server**  
>
> > **Create Branch**  
> >
> > ```shell
> > git branch [branch_name]
> > ```  
>
> > **Attach Branch to Remote Server**  
> >
> > ```shell
> > git push -u origin [branch_name]
> > ```  
>


---   

## Usage  

**Sections**   
*   [Clone Repo to Local Machine](#clone-repo-to-local-machine)  
*   [Create Branch](#create-branch)  
*   [Add Content to a Branch](#add-content-to-a-branch)  
*   [Preview Content](#preview-content)  
*   [Merge Content in Mainline Branch](#merge-content-in-mainline-branch)  
*   [\[Alternate\] Add Content to a Branch](#alternate-add-content-to-a-branch)  
*   [To-Do](#to-do)

---  

## Clone Repo to Local Machine  

In WEB BROWSER.  
1.  While connected to the Amazon network, visit the Spectrum-Evergreen-Content package at [code.amazon.com/packages/Spectrum-Evergreen-Content](https://code.amazon.com/packages/Spectrum-Evergreen-Content) in Amazon Code Browser.  
2.  In the top-right corner, locate the Clone uri text box and copy the shh uri.  
    
    > **EXAMPLE**: `ssh://git.amazon.com/pkg/Spectrum-Evergreen-Content`  

In GIT DESKTOP.  
1.  Clone a repository by chooseing one of the following methods.    
    *   Select **File** > **Clone Repository...**  
    *   Press `Ctrl`+`Shift`+`O`  
    *   Click on **Current repository** button, click on **Add** button, select **Clone Repository...**  
2.  Select on the *URL* tab.  
    1.  In the **Repository URl or GitHub username and repository** text bow, enter the ssh uri.  
    2.  In the **Local path** test box, enter the following location. 
        *   For Windows: `c:\spectrum\git\Spectrum-Evergreen-Content`  
    3.  Click on **Clone** button.  


## Create Branch  

In GIT DESKTOP.  
1.  Click on **Current repository** and select `Spectrum-Evergreen-Content`.  
2.  Click on **Current branch** 
    1.  Click on **New Branch** button.  
3.  On the *Create a branch* pop-up window.  
    1.  In the **Name** text box, enter the name of your branch.  
        
        > **NOTE**: Use your alias or a SIM identifier.  

    2.  Under *Create branch based on...* section.  
        *   Click on **mainline**.  
    3.  Click on **Create branch** button.  


## Add Content to a Branch  
 
> **Editing on your Desktop**  
>
> In GIT DESKTOP.  
> 1.  Click on **Current repository** and select `Spectrum-Evergreen-Content`.  
> 2.  Click on **Current branch** and select your current branch.  
>     
>     > **NOTE**: Be sure to work in your own branch or in a branch associated with a SIM.  
>
> 3.  Click on **Fetch origin**.  
> 4.  Click on **Open with Visual Studio Code** button.  
> 
> In VISUAL STUDIO CODE.  
> 1.  Edit files.  
> 2.  Save changes.  
>
> In GIT DESKTOP.  
> 1.  Under the *Changes* tab.  
>     1.  Select the checkbox for each chnaged file to attach to the commit.  
>     2.  In the **Summary** text box, enter one of the following messages.  
>         *   `Added content.`  
>         *   `Updated content.`  
>         *   `Removed content.`  
>         *   `Added file.`  
>         *   `Removed file.`  
>     3.  In the **Description** text box, enter a brief summary of changes using past tense active statements.  
>         
>         > **EXAMPLE**: `Updated content per TR feedback. Added links. Removed header.`  
>         
>     4.  Click on **Commit to [branch_name]** button.  
>         
>         > **NOTE**: Be sure to work in your own branch or in a branch associated with a SIM.  
>         
>     5.  Click **Push origin** button.  


## Preview Content  

*   Talk to @martinnx to update the preview for your branch on the Developer Desktop.   
    *   Check: use `brazil build`  
    *   Clean and resync package on Developer Desktop. 
    *   Check: git rebase issues with CRUX  


## Merge Content in Mainline Branch  

> **NOTE**: This step is a work in progress.  

*   Talk to @martinnx to merge your branch into Mainline Branch.    
    *   Check: run `brazil build` on branch   


## \[Alternate\] Add Content to a Branch  

In WEB BROWSER.  
1.  While connected to the Amazon network, visit the SPDS API Onboarding site at [evergreen.corp.amazon.com/spds-onboarding](https://evergreen.corp.amazon.com/spds-onboarding).  

> **Editing in Your Web Browser**  
>
> > **IMPORTANT** 
> 
> 1.  Click on the **Edit File Online** icon (located in the top-right corner of each page).  
> 2.  On the *Code Browser* page for the markdown files, under the *Source* tab.  
>     1.  In the **FILE CONTENTS** section, on the left side, edit the markdown content.  
>         
>         > **NOTE**: On the right side, the live preview is displayed.  
>         
>     2.  In the **COMMIT MESSAGE** section, enter your commit message.  
>     3.  Click on **Create Commit** button.  
>     4.  On the *Merge* window, ...  \[ \[ Complete instructions \] \]


## TO-Do

1.  Linters can be added to the pipeline.  
2.  Reviewers can be added to the pipeline.  

