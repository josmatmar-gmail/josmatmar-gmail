# Configuring PuTTY  

To avoid having to enter your Amazon login password multiple times for a single Git operation, you can install PuTTY or edit your PuTTY configuration.  

1.  Visit [www.putty.org](www.putty.org).  
    1.  Click on the *You can download PuTTY [here](https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html)* link.  
    2.  Download the 64-bit Windows installer.  
    3.  Run the installer.  


## Caching server credentials for git.amazon.com  

1.  > Set up environment variable for PuTTY  
    > 
    > > **cmd**  
    > > 
    > > ```
    > > set GIT_SSH=C:\PuTTY\plink.exe
    > > set HOME=%USERPROFILE%
    > > ```  

2.  > Verify environment variable for PuTTY  
    > 
    > > **cmd**  
    > > 
    > > ```
    > > %GIT_SSH%
    > > ```  

3.  > Set up `Default settings` system properties for PuTTY.  
    > 
    > > **gui**  
    > > 
    > > 1.  Open PuTTY.
    > > 2.  Under **Category**.  
    > >     1.  Click on **Connection**.  
    > >         1.  Click on **Data**.  
    > >             
    > >             | field | value/selection |  
    > >             |:--- |:--- |  
    > >             | Auto-login Username | `[amazon_username]` |  
    > >                     
    > >         2.  Click on **Proxy**.  
    > >             
    > >             | field | value/selection |  
    > >             |:--- |:--- |  
    > >             | Proxy type | `None` |  
    > >             
    > >         3.  Click on **SSH**.  
    > >             1.  Click on **Auth**.  
    > >                 1.  Click on **GSSAPI**.  
    > >                     
    > >                     | field | value/selection |  
    > >                     |:--- |:--- |  
    > >                     | Attempt GSSAPI authentication | checked |  
    > >             
    > >     2.  Click on **Session**.  
    > >         1.  Under **Load, save or delete a stored session**.  
    > >             1.  Under **Saved Sessions**.  
    > >                 1.  Select `Default Settings`.  
    > >             2.  Click on **Save** button.  

4.  > Request security certificate on port 22.  
    > 
    > > **gui**  
    > > 
    > > 1.  Open PuTTY.
    > >     1.  Click on **Session**.  
    > >         1.  Under **Specify the destination you want to connect to**.  
    > >             
    > >             | field | value/selection |  
    > >             |:--- |:--- |  
    > >             | Host Name \(or IP address\) | `git.amazon.com` |  
    > >             | Port | `22` |  
    > >             
    > >         2.  Under **Close window on exit:**.  
    > >             1.  Select **Never**.  
    > >     2.  Click **Open** button.  
    >
    > > **cmd**  
    > > 
    > > ```
    > > plink -P 22 git.amazon.com
    > > ```  
    > 
    > Choose Yes to accept.  

5.  > Request security certificate on port 2222.  
    > 
    > > **gui**  
    > > 
    > > 1.  Open PuTTY.
    > >     1.  Click on **Session**.  
    > >         1.  Under **Specify the destination you want to connect to**.  
    > >             
    > >             | field | value/selection |  
    > >             |:--- |:--- |  
    > >             | Host Name \(or IP address\) | `git.amazon.com` |  
    > >             | Port | `2222` |  
    > >             
    > >         2.  Under **Close window on exit:**.  
    > >             1.  Select **Never**.  
    > >     2.  Click **Open** button.  
    >
    > > **cmd**
    > > 
    > > ```
    > > plink -P 2222 git.amazon.com
    > > ```  
    > 
    > Choose Yes to accept.  

