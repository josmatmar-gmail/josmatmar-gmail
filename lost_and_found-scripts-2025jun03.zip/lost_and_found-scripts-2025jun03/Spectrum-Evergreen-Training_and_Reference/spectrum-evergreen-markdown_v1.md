# Spectrum - Evergreen Markdown reference  

**Contents**  
*   [Requirements](#requirements)  
*   [Layout](#layout)  
*   [Link](#link)  
*   [Text Formatting](#text-formatting)  
*   [Site Markdown](#site-markdown)  
*   [PlantUML](#plantuml)  

---  


## Requirements  

In order to access the repository on your local machine, please verify that you meet the following requirements.  

*   Computer running Windows, macOS, or Linux.  
*   Have ssh token set up on your local machine.  
*   Permissions to the following groups and bindles
    *   [apolloop](https://permissions.amazon.com/group.mhtml?target=12071) \(posix\)
    *   [apolloop-misc](https://permissions.amazon.com/group.mhtml?target=1981061) \(posix\)
    *   [SpectrumCM](https://bindles.amazon.com/software_app/SpectrumCM) \(Bindle\)
*   Set up your machine using [spectrum-markdown-instructions.md](spectrum-markdown-instructions.md).  

> **IMPORTANT**: Always end a line with 2 spaces.  


## LAYOUT  

### Header 

> **section link and title**  
>
> > **NOTE**: Every section title is automatically a section link.  
> > 1.  The link is all lower-case.  
> >     
> >     > `shouldn't we use more than 1 of the following: use-cases`  
> >     
> > 2.  All non-alphanumeric characters are replaced with dash marks \(`-`\).  
> >     
> >     > `shouldn-t-we-use-more-than-1-of-the-following--use-cases`  
> >     
> > 3.  If multiple dash marks \(`-`\) are present, then replaced with a single dash mark \(`-`\).  
> >     
> >     > `shouldn-t-we-use-more-than-1-of-the-following-use-cases`  
> >     
> > 4.  Place a hash mark in front to indicate a section link.  
> >     
> >     > `#shouldn-t-we-use-more-than-1-of-the-following-use-cases`  
> >     
>
> ```markdown
> # Shouldn't We Use More Than 1 of the Following: Use-cases  
> 
> Ipsum...  
>
> ## LOREM  
> 
> Lorem...  
>
> ## ID  
> 
> Id...  
> ```  
>
> > # Shouldn't We Use More Than 1 of the Following: Use-cases  
> > 
> > Ipsum...  
> > 
> > ## LOREM  
> > 
> > Lorem...  
> > 
> > ## ID  
> > 
> > Id...  
>

### Unordered  list

> **bulleted list**  
>
> ```markdown
> *   ipsum lorem  
>     *   lorem ipsum  
> ```  
>
> > *   ipsum lorem  
> >     *   lorem ipsum  
> 

### Ordered list  

> **numbered list**  
>
> ```markdown
> 1.  ipsum lorem  
> 5.  lorem  
>     1.  lorem ipsum  
> ```  
>
> > 1.  ipsum lorem  
> > 5.  lorem  
> >     1.  lorem ipsum
>

### Table  

> **table**  
>
> ```markdown
> | header 1         | text align left  | text align right | text align justify |  
> | ---              |:---              | ---:             |:---:               |  
> | row one column 1 | row one column 2 | row one column 3 | row one column 3   |  
> | row two column 1 | row two column 2 | row two column 3 | row two column 3   |  
> ```  
>
> > | header 1         | text align left  | text align right | text align justify |  
> > | ---              |:---              | ---:             |:---:               |  
> > | row one column 1 | row one column 2 | row one column 3 | row one column 3   |  
> > | row two column 1 | row two column 2 | row two column 3 | row two column 3   |  
>

### Blockquote  

> **blockquote**  
>
> ```markdown
> > ipsum lorem  
> > lorem  
> > lorem ipsum  
> ```  
>
>
> > ipsum lorem  
> > lorem  
> > lorem ipsum  
>

### Code

> **Code block**  
>
> > <br />\```[code_language]  
> > ipsum lorem\(\) {<br />
> > &nbsp;&nbsp;&nbsp;&nbsp;lorem<br />
> > }<br />
> > lorem ipsum  
> > \```<br /><br />
>
> > ```[code_language]
> > ipsum lorem() {
> >     lorem
> > }
> > lorem ipsum
> > ```
>

> **Code**  
>
> > \`ipsum\`  
>
> > `ipsum`
>


## LINK   

> **external link**  
>
> ```markdown
> [display_text](hyperlink)  
> ```  
>
> > [display_text](hyperlink)

> **internal link**  
>
> ```markdown
> [display_text](#section-title-in-lowercase)  
> ```  
>
> > [display_text](#section-title-in-lowercase)

> **image**  
>
> ```markdown
> ![alternative_text](hyperlink.file_extension)
> ```  
>
> > ![alternative_text](hyperlink.file_extension)


## TEXT FORMATTING  

### Bold  

> **bold**  
>
> ```markdown
> **ipsum lorem**  
> ```  
>
> > **ipsum lorem** 

### Italics  

> **italic**  
>
> ```markdown
> *ipsum lorem*  
> ```  
>
> > *ipsum lorem* 

### Bold-Italics  

> **bold-italic**  
>
> ```markdown
> ***ipsum lorem***  
> ```  
>
> > ***ipsum lorem*** 

### Strike-through  

> **strike-through**  
>
> ```markdown
> ~~ipsum lorem~~  
> ```  
>
> > ~~ipsum lorem~~


## Site Markdown  

### Important  

> **important**
>
> ```markdown
> > **IMPORTANT**: Ipsum Lorem...  
> ```  
>
> > > **IMPORTANT**: Ipsum Lorem...  

### Note  

> **note**
>
> ```markdown
> > **NOTE**: Ipsum Lorem...  
> ```  
>
> > > **NOTE**: Ipsum Lorem...  

### Review note  

> **review note**
>
> ```markdown
> > **REVIEW NOTE**: Ipsum Lorem...  
> ```  
>
> > > **REVIEW NOTE**: Ipsum Lorem...  

### Tip  

> **tip**
>
> ```markdown
> > **TIP**: Ipsum Lorem...  
> ```  
>
> > > **TIP**: Ipsum Lorem...  



## PlantUML  

### Using PlantUML  

[Amazon API wiki - Customer Context - Design](https://w.amazon.com/bin/view/AmazonAPI/Internal/AmazonAPI2018Roadmap/CustomerContext2018/Design)  

