

Hi , 
Can you or a member of your team answer a few questions about AWS?  

I am a tech writer on the Spectrum Change Management (CM) team within the SPS org.  

Is it possible to partner with AWS to leverage the technologies and training produced for content creation and deployment? 
*   Can another organization in Amazon leverage the AWS build process to create non-AWS pipelines for content delivery? 
Is AWS open to partnering with other non-AWS organizations?  
*   Are there any limitations that would prevent AWS from partnering with other organizations within Amazon? 
*   What are the requirements associated with partnering with AWS? 

Thank you,  


*   Collaborate with peers and stakeholders to identify the issues with maintaining and building developer docs that that provide feedback mechanisms to the Spectrum team (including PM team, CM team, and DevSu).
*   Identify blockers for acceptance.
*   Deliver project expectations and summary.
*   Identify the requirements for analytics to be useful for Spectrum. The requirements may include the following.
    *   Thumbs up and thumbs down
    *   Page-level tracking (visitor focus, time, click-through)
    *   GitHub issues
    *   Adobe Analytics
    *   SIM (internal only)
    *   CR using CRUX (internal only)


*   Meet with AWS teams to determine viability of deploying SPDS content with AWS partnership. The content would include the existing content delivered from Swagger (SPDS APIs) and markdown (developer guide).